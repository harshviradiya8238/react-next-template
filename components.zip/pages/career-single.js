import About from "../components/careerSingle/About";
import Banner from "../components/careerSingle/Banner";

export default function CareerSingle(params) {
  return (
    <>
      <Banner />
      <About />
    </>
  );
}

export const accounts = [
  {
    id: 1,
    question: "How do I locate the nearesty branch or ATM?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 2,
    question: "What do I do if I lose my card or it gets stolen?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 3,
    question: "What is your customer service number?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 4,
    question: "How do I reset my pin?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 5,
    question: "What is required to use Digital Banking?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 6,
    question: "Is digital banking secure?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
];

export const affiliates = [
  {
    id: 1,
    question: "How do I locate the nearesty branch or ATM?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 2,
    question: "What do I do if I lose my card or it gets stolen?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 3,
    question: "What is your customer service number?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 4,
    question: "How do I reset my pin?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 5,
    question: "What is required to use Digital Banking?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 6,
    question: "Is digital banking secure?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
];

export const securitys = [
  {
    id: 1,
    question: "How do I locate the nearesty branch or ATM?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 2,
    question: "What do I do if I lose my card or it gets stolen?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 3,
    question: "What is your customer service number?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 4,
    question: "How do I reset my pin?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 5,
    question: "What is required to use Digital Banking?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
  {
    id: 6,
    question: "Is digital banking secure?",
    answer:
      " If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120.",
  },
];

exports.id = 5179;
exports.ids = [5179];
exports.modules = {

/***/ 5179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_stepper_horizontal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4522);
/* harmony import */ var react_stepper_horizontal__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_stepper_horizontal__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(483);
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5994);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
/* harmony import */ var _utils_Notification__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4112);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _navBar_NavBar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3894);
/* harmony import */ var _helper_API__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7313);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_8__, _helper_API__WEBPACK_IMPORTED_MODULE_12__]);
([axios__WEBPACK_IMPORTED_MODULE_8__, _helper_API__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














// Define the validation schema
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
    step1: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        lastName: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Last Name is required"),
        firstName: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("First Name is required"),
        email: yup__WEBPACK_IMPORTED_MODULE_3__.string().email("Invalid email format").required("Email is required"),
        phone: yup__WEBPACK_IMPORTED_MODULE_3__.string().matches(/^\d{10}$/, "Please enter 10 digits").required("Contact Number is required")
    }),
    stepVerify: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        mobileotp: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Mobile OTP is required"),
        emailotp: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Email OTP is required")
    }),
    step2: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        loanAmount: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Loan Amount is required"),
        loanTerm: yup__WEBPACK_IMPORTED_MODULE_3__.number().lessThan(20, "Value must be less than 20"),
        loanType: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("LoanType is required"),
        State: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("State is required")
    }),
    step2verify: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        loanAmount: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Loan Amount is required")
    }),
    step3: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        businessProof: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Address is required"),
        gst: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("City is required"),
        panCard: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Country is required")
    })
});
function ApplyForLoan() {
    const [selectedRow, setSelectedRow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [state, setSatate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        step1: {
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            refer: ""
        },
        stepVerify: {
            mobileotp: "",
            emailotp: ""
        },
        step2: {
            loanType: "",
            loanAmount: "",
            loanTerm: "",
            state: ""
        },
        step3: {
            businessProof: [],
            gst: [],
            panCard: [],
            adharCard: [],
            lightBill: [],
            itr: [],
            bankStatement: []
        },
        activeStep: 0
    });
    const stepsmain = [
        {
            title: "Basic Details"
        },
        {
            title: "Loan Details"
        },
        {
            title: "Document Details"
        },
        {
            title: "Application confirmation"
        }
    ];
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Extract referralCode from query params
        const { referralCode  } = router.query;
        if (referralCode) {
            setSatate((prevFormData)=>({
                    ...prevFormData,
                    step1: {
                        ...prevFormData.step1,
                        refer: referralCode
                    }
                }));
        }
    }, [
        router.query
    ]);
    const [buttonDisabled, setButtonDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [sendOtp, setVerifyOtp] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [eligiblity, setEligiblity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [apiData, setapiData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [loanTypeOption, setLoanTypeOption] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [countryStateOption, SetCountryStateOption] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [countryState, SetCountryState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [selectOption, setSelectOption] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [bankOption, setBankOption] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [documentOption, setDocumentOption] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectOptionName, setSelectOptionName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loanApplicationId, setLoanAppliactionId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loanApplicationNumber, setLoanAppliactionNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [errorLoanType, setErrorLoanType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [errorStateType, setErrorStateType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loanAmount, setLoanAmount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [otherDocumentId, setOtherDocumentId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loanAmountError, setLoanAmountError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loanTerm, setLoanTerm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [errorLoanTerm, setErrorLoanTerm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [pincode, setPincode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [city, setCity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [cityError, setCityError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [pincodeError, setPincodeError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [isLoanCreat, setIsLoanCreat] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [userLoginData, setUserLoginData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const CurrentStep = Number(localStorage.getItem("currentStep")) || 0;
        setSatate((oldState)=>{
            return {
                ...oldState,
                activeStep: CurrentStep
            };
        });
        const GetAll = async ()=>{
            const token = localStorage.getItem("logintoken");
            if (token) {
                try {
                    const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].get */ .Z.get("/LoanType/GetAll", {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    });
                    const { data  } = response;
                    setLoanTypeOption(data?.value?.gridRecords);
                } catch (error) {
                    console.log(error);
                // Notification("error", error?.response?.data[0]?.errorMessage);
                }
            }
        };
        const GetAllState = async ()=>{
            try {
                const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].get */ .Z.get("/State/GetAll");
                const { data  } = response;
                SetCountryStateOption(data.value);
            } catch (error) {
                console.log(error);
            }
        };
        GetAll();
        GetAllState();
    }, []);
    const handleSelectoption = ({ target  })=>{
        setSelectOption(target.value);
        setSelectOptionName(target.name);
        setErrorLoanType("");
    };
    const handleSelectStateoption = ({ target  })=>{
        SetCountryState(target.value);
        setErrorStateType("");
    // setSelectOptionName(target.name);
    };
    const handleChnageLoanAmount = ({ target  })=>{
        if (/^\d*\.?\d*$/.test(target.value) || target.value === "") {
            setLoanAmount(target.value);
        }
        setLoanAmountError("");
    // setSelectOptionName(target.name);
    };
    const handlehangeLoanTerm = ({ target  })=>{
        const inputValue = target.value;
        if (inputValue === "" || 0 <= parseInt(inputValue) && parseInt(inputValue) <= 20) {
            setLoanTerm(inputValue);
            setErrorLoanTerm("");
        } else {
            setErrorLoanTerm("please enter loan tenure between 0 to 20");
            setLoanTerm(inputValue);
        }
    };
    const handlePincodeChange = async (event)=>{
        const newPincode = event.target.value;
        setPincode(newPincode);
        if (newPincode.length === 6) {
            try {
                const response = await axios__WEBPACK_IMPORTED_MODULE_8__["default"].get(`https://dev.yowza.international/location/details/${newPincode}`);
                const { places , state , country , City  } = response.data.data;
                setCity(City);
                setPincodeError("");
            } catch (error) {
                (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", "invalid Pincode");
                console.error("Error fetching data:", error);
                setCity("");
            }
        } else {
            setCity("");
        }
    };
    const handleCityChange = (event)=>{
        setCity(event.target.value);
        if (event.target.value.length) {
            setCityError("");
        }
    };
    const aRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const handleSendOtp = async (data, value)=>{
        if (value.step1.firstName && value.step1.lastName && value.step1.email && value.step1.phone && value.step1.phone.toString().length === 10) {
            setButtonDisabled(true);
            try {
                const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post("/User/Create", {
                    firstName: value.step1.firstName,
                    lastName: value.step1.lastName,
                    email: value.step1.email,
                    phoneNumber: Number(value.step1.phone),
                    referrerCode: value.step1.refer
                });
                const { data: data1  } = response;
                if (data1?.success) {
                    await (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", "OTP sent successFully");
                    setVerifyOtp(true);
                    setButtonDisabled(false);
                    setapiData(value);
                } else {
                    await (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", data1[0]?.errorMessage);
                }
            } catch (error) {
                setButtonDisabled(false);
                (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", error?.response?.data[0]?.errorMessage);
            }
        }
    };
    const handleCreateApplication = async (e, value, setFieldValue)=>{
        e.preventDefault();
        if (!selectOption) {
            setErrorLoanType("Please Select Loan Type.");
        }
        if (!countryState) {
            setErrorStateType("Please Select State");
        }
        if (!loanAmount) {
            setLoanAmountError("Please Enter Loan Amount");
        }
        if (!city) {
            setCityError("Please Enter city");
        }
        if (!pincode) {
            setPincodeError("Please Enter pincode");
        }
        if (!loanAmount || !selectOption || !countryState || !city || !pincode) {
            return;
        }
        try {
            const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post("/LoanApplication/Create", {
                loanTypeId: selectOption,
                amount: loanAmount,
                tenure: Number(loanTerm),
                stateId: Number(countryState),
                city: city,
                postalCode: pincode
            });
            const { data  } = response;
            await (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", "Loan application created successfully");
            GetBankAndDocumetByLoanTypeId(selectOption, loanAmount, loanTerm, setFieldValue);
            setLoanAppliactionId(data?.value?.id);
            setLoanAppliactionNumber(data?.value?.applicationNumber);
            setIsLoanCreat(true);
        } catch (error) {
            console.log(error);
        // Notification("error", "Please Enter All Field");
        // Notification("error", error?.response?.data[0]?.errorMessage);
        }
    };
    const updateLoanApplication = async (value, setFieldValue)=>{
        if (!selectOption) {
            setErrorLoanType("Please Select Loan Type.");
        }
        if (!countryState) {
            setErrorStateType("Please Select State");
        }
        if (!loanAmount) {
            setLoanAmountError("Please Enter Loan Amount");
        }
        if (!city) {
            setCityError("Please Enter City");
        }
        if (!pincode) {
            setPincodeError("Please Enter pincode");
        }
        if (!loanAmount || !selectOption || !countryState || !city || !pincode) {
            return;
        }
        try {
            const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post("/LoanApplication/UpdateLoanApplication", {
                loanApplicationId: loanApplicationId,
                bankIds: selectedRowData,
                loanTypeId: selectOption,
                amount: Number(loanAmount),
                tenure: Number(loanTerm),
                stateId: Number(countryState),
                city: city,
                postalCode: pincode,
                isActive: true
            });
            const { data  } = response;
            await (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", data?.messages[0]?.messageText);
            GetBankAndDocumetByLoanTypeId(selectOption, loanAmount, loanTerm, setFieldValue);
        // setIsLoanCreat(true);
        } catch (error) {
            console.log(error);
        // Notification("error", "Please Enter All Field");
        // Notification("error", error?.response?.data[0]?.errorMessage);
        }
    };
    const [selectedRowData, setSelectedRowData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [docFiles, setdocFiles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [uploadedFiles, setUploadedFiles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [uploadedOtherDocuemnt, setuploadedOtherDocuemnt] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedFilesArray, setSelectedFilesArray] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const handleCheckboxChange = (event, rowData)=>{
        if (event.target.checked) {
            setSelectedRowData((prevSelectedRowData)=>[
                    ...prevSelectedRowData,
                    rowData.id
                ]);
        } else {
            setSelectedRowData((prevSelectedRowData)=>prevSelectedRowData.filter((row)=>row !== rowData.id));
        }
    };
    const GetBankAndDocumetByLoanTypeId = async (id, Loanamount, tenure, setFieldValue)=>{
        try {
            const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post(`/LoanApplication/GetBankAndDocumetByLoanTypeId`, {
                loanTypeId: id,
                tenure: Number(tenure),
                amount: Loanamount
            });
            const { data  } = response;
            if (data?.value?.bank?.length > 0) {
                setBankOption([
                    ...data.value.bank
                ]);
            } else {
                setFieldValue("activeStep", 2);
                setBankOption([]);
            }
            if (data?.value?.document?.length > 0) {
                const filteredData = data?.value?.document.filter((item)=>item.name !== "Other");
                setDocumentOption(filteredData);
            }
            setOtherDocumentId(data?.value?.otherDocumentId);
        } catch (error) {
            console.log(error);
            (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", error?.response?.data[0]?.errorMessage);
        }
    };
    const handleNext = async (setFieldValue, values)=>{
        setFieldValue("activeStep", values.activeStep + 1);
    };
    const handlePrevious = (setFieldValue, values)=>{
        if (values.activeStep === 1) {
            setButtonDisabled(false);
            setVerifyOtp(false);
        }
        setFieldValue("activeStep", values.activeStep - 1);
    };
    const handleSubmit = (values)=>{
    // Handle form submission
    };
    const handlePreviewFile = (file)=>{
        if (file) {
            const reader = new FileReader();
            reader.onload = ()=>{
                if (file?.type === "application/pdf") {
                    const previewWindow = window.open("", "_blank");
                    const content = `<embed src="${reader.result}" type="application/pdf" width="100%" height="1000px" />`;
                    previewWindow.document.write(content);
                    previewWindow.document.close();
                } else {
                    const previewWindow1 = window.open("", "_blank");
                    const content1 = `<img src="${reader.result}" alt="Preview" />`;
                    previewWindow1.document.write(content1);
                    previewWindow1.document.close();
                }
            };
            reader.readAsDataURL(file);
        }
    };
    const handleSubmitUploadDoc = async (setFieldValue)=>{
        const allUploadEmpty = Object.values(uploadedFiles).every((array)=>array.length === 0);
        if (allUploadEmpty && uploadedOtherDocuemnt.length == 0) {
            (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", "Please Upload atleast one document ");
            return;
        } else {
            setFieldValue("activeStep", 3);
        }
    };
    const handlePanFileChange = (fieldType, event, id)=>{
        if (event.target.files.length) {
            for(let index = 0; index < event.target.files.length; index++){
                event.target.files[index].documentTypeId = id;
            }
        } else {
            event.target.files[0].documentTypeId = id;
        }
        var selectedFiles = [
            ...event?.target?.files
        ];
        setdocFiles((prevState)=>({
                ...prevState,
                [fieldType]: selectedFiles
            }));
    };
    const handleRemoveFile = (fieldType, index)=>{
        setdocFiles((prevState)=>({
                ...prevState,
                [fieldType]: prevState[fieldType].filter((_, i)=>i !== index)
            }));
    };
    const handleKeyPress = (event)=>{
        var charCode = event.which ? event.which : event.keyCode;
        if (String.fromCharCode(charCode).match(/[^0-9]/g) || event.target.value.length > 5) {
            event.preventDefault();
        }
    };
    const [documentFileName, setDocumentFileName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [selectedFile, setSelectedFile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [errorMessage, setErrorMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const allowedFileTypes = [
        ".jpg",
        ".jpeg",
        ".png",
        ".pdf"
    ];
    const maxFileSize = 10 * 1024 * 1024;
    const handleFileChange = (event)=>{
        const files = event.target.files;
        if (!documentFileName) {
            setErrorMessage("Please enter a document name before selecting a file");
            return;
        }
        let newFileArray = [];
        let unsupportedFileType = false;
        let exceededFileSize = false;
        for(let i = 0; i < files.length; i++){
            const file = files[i];
            const fileType = "." + file.name.split(".").pop().toLowerCase();
            if (allowedFileTypes.includes(fileType) && file.size <= maxFileSize) {
                newFileArray.push({
                    name: documentFileName,
                    file
                });
            } else {
                if (!allowedFileTypes.includes(fileType)) {
                    unsupportedFileType = true;
                }
                if (file.size > maxFileSize) {
                    exceededFileSize = true;
                }
            }
        }
        if (newFileArray.length > 0) {
            setSelectedFilesArray((prevArray)=>[
                    ...prevArray,
                    ...newFileArray
                ]);
        }
        if (unsupportedFileType && exceededFileSize) {
            setErrorMessage("Some file types are not supported and some files exceeded the size limit of 10 MB");
        } else if (unsupportedFileType) {
            setErrorMessage("Some file types are not supported");
        } else if (exceededFileSize) {
            setErrorMessage("Some files exceeded the size limit of 10 MB");
        } else {
            setErrorMessage("");
        }
    };
    const handleRemoveOtherDocumentFile = (fileToRemove)=>{
        const updatedFiles = selectedFilesArray.filter((fileObj)=>fileObj.file !== fileToRemove);
        setSelectedFilesArray(updatedFiles);
    };
    const handleUpload = ()=>{
        if (selectedFile && documentFileName) {
            setSelectedFilesArray((prevArray)=>[
                    ...prevArray,
                    {
                        name: documentFileName,
                        file: selectedFile
                    }
                ]);
            setSelectedFile(null);
            setDocumentFileName("");
            setErrorMessage("");
        } else {
            setErrorMessage("Please enter a document name and choose a file to upload");
        }
    };
    const handleUploadForField = async (id, name)=>{
        const files = docFiles[name]; // Assuming docFiles is an object where keys are the document names and values are arrays of File objects
        const formData = new FormData();
        files && files.forEach(async (element, index)=>{
            // Here 'files' is the FormData key. It may vary based on your backend requirement.
            formData.append("DocumentTypeId", element.documentTypeId);
            formData.append("Documents", element);
            formData.append("LoanApplicationId", loanApplicationId);
        });
        if (files || files.length) {
            const token = localStorage.getItem("logintoken");
            try {
                const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post("/LoanApplication/UploadLoanDocument", formData, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        "Content-Type": "multipart/form-data"
                    }
                });
                (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", "Document uploaded successfully ");
                const newDocFiles = {
                    ...docFiles
                };
                newDocFiles[name] = [];
                setdocFiles(newDocFiles);
                // setFieldValue("activeStep", 2);
                setUploadedFiles((prevState)=>({
                        ...prevState,
                        [name]: [
                            ...prevState[name] || [],
                            ...files
                        ]
                    }));
            } catch (error) {
                console.log(error);
                (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", error?.response?.data[0]?.errorMessage);
            }
        } else {
            (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", "Please Upload atleast one document");
        }
    };
    const handleUploadForOtherDocument = async ()=>{
        if (!otherDocumentId || selectedFilesArray.length === 0 || !documentFileName) {
            setErrorMessage("Please enter document name");
            return;
        }
        for (const { name , file  } of selectedFilesArray){
            const formData = new FormData();
            formData.append("LoanApplicationId", loanApplicationId);
            formData.append("DocumentTypeId", otherDocumentId);
            formData.append("Documents", file);
            formData.append("OtherDocumentName", name);
            // Add the ID here
            try {
                const token = localStorage.getItem("logintoken");
                const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post("/LoanApplication/UploadLoanDocument", formData, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        "Content-Type": "multipart/form-data"
                    }
                });
                // const { data } = response;
                (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", "Document uploaded successfully ");
                // setSelectedFilesArray([]);
                setSelectedFilesArray([]);
                setDocumentFileName("");
                const newUploadedDocs = [
                    ...uploadedOtherDocuemnt,
                    ...selectedFilesArray
                ];
                setuploadedOtherDocuemnt(newUploadedDocs);
            // setFieldValue("activeStep", 2);
            } catch (error) {
                console.log(error);
                (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", error?.response?.data[0]?.errorMessage);
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "apply-for-loan business-loan",
        id: "business-loan-form",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_navBar_NavBar__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                userLoginData: userLoginData
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "overlay pt-120",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container wow fadeInUp",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "row justify-content-center"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "row justify-content-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-content",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "section-header text-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "title",
                                                    children: "Apply for Loan"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Please fill the form below. We will get in touch with you within 1-2 business days, to request all necessary details"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "stepper-main",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                                initialValues: state,
                                                validationSchema: validationSchema,
                                                onSubmit: handleSubmit,
                                                enableReinitialize: true,
                                                children: ({ isSubmitting , values , setFieldValue , onChange , setFieldError  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(formik__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_stepper_horizontal__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                steps: stepsmain,
                                                                activeStep: values.activeStep
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "stepper-field-form",
                                                                children: [
                                                                    values.activeStep === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        children: sendOtp ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "row",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "col-6",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "single-input",
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                    children: [
                                                                                                        " ",
                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                            className: "astrisk_mark",
                                                                                                            children: "*"
                                                                                                        }),
                                                                                                        "Mobile OTP:"
                                                                                                    ]
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                    name: "stepVerify.mobileotp",
                                                                                                    placeholder: "Enter Mobile OTP ",
                                                                                                    type: "number",
                                                                                                    onKeyPress: (event)=>{
                                                                                                        handleKeyPress(event);
                                                                                                    },
                                                                                                    onInput: (event)=>{
                                                                                                        if (event.target.value.length > 7) {
                                                                                                            event.preventDefault();
                                                                                                        }
                                                                                                    }
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.ErrorMessage, {
                                                                                                    name: "stepVerify.mobileotp",
                                                                                                    component: "div",
                                                                                                    className: "all_error"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "col-6",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "single-input",
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                    children: [
                                                                                                        " ",
                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                            className: "astrisk_mark",
                                                                                                            children: "*"
                                                                                                        }),
                                                                                                        "Email OTP:"
                                                                                                    ]
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                    name: "stepVerify.emailotp",
                                                                                                    type: "number",
                                                                                                    placeholder: "Enter Email OTP",
                                                                                                    onKeyPress: (event)=>{
                                                                                                        handleKeyPress(event);
                                                                                                    },
                                                                                                    onInput: (event)=>{
                                                                                                        if (event.target.value.length > 7) {
                                                                                                            event.preventDefault();
                                                                                                        }
                                                                                                    }
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.ErrorMessage, {
                                                                                                    name: "stepVerify.emailotp",
                                                                                                    component: "div",
                                                                                                    className: "all_error"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "d-flex justify-content-start align-items-center",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "submit",
                                                                                            onClick: async ()=>{
                                                                                                {
                                                                                                    const { mobileotp , emailotp  } = values.stepVerify || {};
                                                                                                    // Check if the mobile OTP or email OTP is undefined or empty
                                                                                                    if (typeof mobileotp === "undefined" || typeof emailotp === "undefined" || !mobileotp || !emailotp) {
                                                                                                        if (typeof mobileotp === "undefined" || !mobileotp) {
                                                                                                            setFieldError("stepVerify.mobileotp", "Mobile OTP is required1111111111111111");
                                                                                                        }
                                                                                                        if (typeof emailotp === "undefined" || !emailotp) {
                                                                                                            setFieldError("stepVerify.emailotp", "Email OTP is required");
                                                                                                        }
                                                                                                        return; // Stop further execution if either of the OTPs is undefined or empty
                                                                                                    }
                                                                                                    try {
                                                                                                        const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post("/User/VerifyOTP", {
                                                                                                            sendEmail: true,
                                                                                                            email: apiData.step1.email,
                                                                                                            phoneNumber: Number(apiData.step1.phone),
                                                                                                            mobileOTP: values.stepVerify.mobileotp.toString(),
                                                                                                            emailOTP: values.stepVerify.emailotp.toString()
                                                                                                        });
                                                                                                        const { data  } = response;
                                                                                                        if (data?.success) {
                                                                                                            const tokenData = data?.value?.token;
                                                                                                            await window.localStorage.setItem("logintoken", tokenData);
                                                                                                            await window.localStorage.setItem("user", JSON.stringify(data?.value));
                                                                                                            await localStorage.setItem("currentStep", 1);
                                                                                                            setUserLoginData(data?.value);
                                                                                                            await setVerifyOtp(true);
                                                                                                            await (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", "OTP verified successfully and password is sent on your email id");
                                                                                                            await window.location.reload();
                                                                                                            await handleNext(setFieldValue, values);
                                                                                                        }
                                                                                                    } catch (error) {
                                                                                                        console.log(error);
                                                                                                        (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", error?.response?.data[0].errorMessage);
                                                                                                    }
                                                                                                }
                                                                                            },
                                                                                            className: "cmn-btn",
                                                                                            children: "Verify OTP"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "row",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "col-6",
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "single-input",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                className: "astrisk_mark",
                                                                                                                children: "*"
                                                                                                            }),
                                                                                                            "First Name:"
                                                                                                        ]
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                        type: "text",
                                                                                                        name: "step1.firstName",
                                                                                                        placeholder: "First Name "
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.ErrorMessage, {
                                                                                                        name: "step1.firstName",
                                                                                                        component: "div",
                                                                                                        className: "all_error"
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "col-6",
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "single-input",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                        children: [
                                                                                                            " ",
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                className: "astrisk_mark",
                                                                                                                children: "*"
                                                                                                            }),
                                                                                                            "Last Name:",
                                                                                                            " "
                                                                                                        ]
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                        type: "text",
                                                                                                        name: "step1.lastName",
                                                                                                        placeholder: "Last Name"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.ErrorMessage, {
                                                                                                        name: "step1.lastName",
                                                                                                        component: "div",
                                                                                                        className: "all_error"
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "col-6",
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "single-input",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                        children: [
                                                                                                            " ",
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                className: "astrisk_mark",
                                                                                                                children: "*"
                                                                                                            }),
                                                                                                            "Email:"
                                                                                                        ]
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                        type: "email",
                                                                                                        name: "step1.email",
                                                                                                        placeholder: "Email"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.ErrorMessage, {
                                                                                                        name: "step1.email",
                                                                                                        component: "div",
                                                                                                        className: "all_error"
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "col-6",
                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "single-input",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                        children: [
                                                                                                            " ",
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                className: "astrisk_mark",
                                                                                                                children: "*"
                                                                                                            }),
                                                                                                            "Contact No:"
                                                                                                        ]
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                        className: "mobile-number-input",
                                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                            type: "number",
                                                                                                            onKeyPress: (event)=>{
                                                                                                                if (event.target.value.length > 9) {
                                                                                                                    event.preventDefault();
                                                                                                                }
                                                                                                            },
                                                                                                            name: "step1.phone",
                                                                                                            // className="indian-flag"
                                                                                                            placeholder: "Contact Number"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.ErrorMessage, {
                                                                                                        name: "step1.phone",
                                                                                                        component: "div",
                                                                                                        className: "error_phone"
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        className: "cmn-btn",
                                                                                        disabled: !values.step1.firstName || !values.step1.lastName || !values.step1.email || !values.step1.phone || values.step1.phone && values.step1.phone.toString().length !== 10 || buttonDisabled,
                                                                                        onClick: ()=>{
                                                                                            handleSendOtp(setFieldValue, values);
                                                                                        },
                                                                                        children: "Next"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    values.activeStep === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                        children: bankOption && bankOption.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    class: "table-section",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                            className: "text-head",
                                                                                            children: [
                                                                                                " ",
                                                                                                "Choose your Preference"
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                                            class: "table",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                                scope: "col",
                                                                                                                children: "Sr.No"
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                                scope: "col",
                                                                                                                children: "Bank Name"
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                                                    children: bankOption && bankOption.map((elm, index)=>{
                                                                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                            class: "checkbox",
                                                                                                                            children: [
                                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                                                    type: "checkbox",
                                                                                                                                    checked: selectedRowData.includes(elm.id),
                                                                                                                                    onChange: (e)=>handleCheckboxChange(e, elm)
                                                                                                                                }),
                                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                                    class: "checkbox-circle",
                                                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                                                                                                        viewBox: "0 0 52 52",
                                                                                                                                        class: "checkmark",
                                                                                                                                        children: [
                                                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                                                                                fill: "none",
                                                                                                                                                r: "25",
                                                                                                                                                cy: "26",
                                                                                                                                                cx: "26",
                                                                                                                                                class: "checkmark-circle"
                                                                                                                                            }),
                                                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                                                                                d: "M16 26l9.2 8.4 17.4-21.4",
                                                                                                                                                class: "checkmark-kick"
                                                                                                                                            })
                                                                                                                                        ]
                                                                                                                                    })
                                                                                                                                })
                                                                                                                            ]
                                                                                                                        })
                                                                                                                    }),
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                                        children: elm?.name
                                                                                                                    })
                                                                                                                ]
                                                                                                            }, index)
                                                                                                        });
                                                                                                    })
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "d-flex justify-content-start align-items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "button",
                                                                                            className: "cmn-btn me-3",
                                                                                            onClick: ()=>{
                                                                                                setBankOption([]);
                                                                                            },
                                                                                            children: "Previous"
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "button",
                                                                                            className: "cmn-btn",
                                                                                            onClick: async ()=>{
                                                                                                handleNext(setFieldValue, values);
                                                                                                if (selectedRowData.length > 0) {
                                                                                                    try {
                                                                                                        const response = await _helper_API__WEBPACK_IMPORTED_MODULE_12__/* ["default"].post */ .Z.post(`/LoanApplication/UpdateLoanApplication`, {
                                                                                                            isActive: true,
                                                                                                            loanApplicationId: loanApplicationId,
                                                                                                            bankIds: selectedRowData,
                                                                                                            tenure: Number(loanTerm),
                                                                                                            loanTypeId: selectOption,
                                                                                                            amount: loanAmount,
                                                                                                            stateId: Number(countryState),
                                                                                                            city: city
                                                                                                        });
                                                                                                        const { data  } = response;
                                                                                                        await (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("success", "Bank selection Submitted successfully");
                                                                                                    } catch (error) {
                                                                                                        console.log(error);
                                                                                                        (0,_utils_Notification__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("error", "error");
                                                                                                    }
                                                                                                } else {
                                                                                                    handleNext(setFieldValue, values);
                                                                                                }
                                                                                            },
                                                                                            children: "Next"
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                class: "custom_padding",
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "row",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "col-6",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "single-input",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                children: [
                                                                                                                    " ",
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                        className: "astrisk_mark",
                                                                                                                        children: "*"
                                                                                                                    }),
                                                                                                                    "Loan Amount (INR)"
                                                                                                                ]
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                                type: "text",
                                                                                                                onKeyPress: (event)=>{
                                                                                                                    if (loanAmount.length === 0 && event.key === "0") {
                                                                                                                        // Prevent the default behavior (inserting "0")
                                                                                                                        event.preventDefault();
                                                                                                                    }
                                                                                                                },
                                                                                                                placeholder: "Enter loan amount",
                                                                                                                value: loanAmount,
                                                                                                                onChange: handleChnageLoanAmount
                                                                                                            }),
                                                                                                            loanAmountError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                className: "all_error",
                                                                                                                children: loanAmountError
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "col-6",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "single-input",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                children: [
                                                                                                                    " ",
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                        className: "astrisk_mark",
                                                                                                                        children: "*"
                                                                                                                    }),
                                                                                                                    "Loan Type"
                                                                                                                ]
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                                children: loanTypeOption && loanTypeOption.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                                                                    className: "selectDrop form-select",
                                                                                                                    value: selectOption,
                                                                                                                    onChange: handleSelectoption,
                                                                                                                    children: [
                                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                                            disabled: true,
                                                                                                                            value: "",
                                                                                                                            children: "Select Loan Type"
                                                                                                                        }),
                                                                                                                        loanTypeOption.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                                                    value: data?.id,
                                                                                                                                    children: data?.name
                                                                                                                                }, index)
                                                                                                                            }))
                                                                                                                    ]
                                                                                                                })
                                                                                                            }),
                                                                                                            errorLoanType && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                className: "all_error",
                                                                                                                children: errorLoanType
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "row",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "col-6",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "single-input",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                                                children: "Loan Tenure (Year)"
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                                type: "number",
                                                                                                                name: "loanTerm",
                                                                                                                value: loanTerm,
                                                                                                                placeholder: "1 Year",
                                                                                                                onChange: handlehangeLoanTerm,
                                                                                                                onKeyPress: (event)=>{
                                                                                                                    var charCode = event.which ? event.which : event.keyCode;
                                                                                                                    if (String.fromCharCode(charCode).match(/[^0-9]/g) || event.target.value.length > 1) {
                                                                                                                        event.preventDefault();
                                                                                                                    }
                                                                                                                }
                                                                                                            }),
                                                                                                            errorLoanTerm && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                className: "all_error",
                                                                                                                children: errorLoanTerm
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "col-6",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "single-input",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                        className: "astrisk_mark",
                                                                                                                        children: "*"
                                                                                                                    }),
                                                                                                                    "State"
                                                                                                                ]
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                                children: countryStateOption && countryStateOption.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                                                                    className: "selectDrop form-select",
                                                                                                                    // aria-label="Default select example"
                                                                                                                    value: countryState,
                                                                                                                    onChange: handleSelectStateoption,
                                                                                                                    children: [
                                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                                            disabled: true,
                                                                                                                            value: "",
                                                                                                                            children: "Select State"
                                                                                                                        }),
                                                                                                                        countryStateOption.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                                                                value: data?.id,
                                                                                                                                children: data?.name
                                                                                                                            }, index))
                                                                                                                    ]
                                                                                                                })
                                                                                                            }),
                                                                                                            errorStateType && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                className: "all_error",
                                                                                                                children: errorStateType
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "row",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "col-6",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "single-input",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                children: [
                                                                                                                    " ",
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                        className: "astrisk_mark",
                                                                                                                        children: "*"
                                                                                                                    }),
                                                                                                                    "Pincode"
                                                                                                                ]
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                                type: "text",
                                                                                                                value: pincode,
                                                                                                                onChange: handlePincodeChange,
                                                                                                                placeholder: "Enter Pincode"
                                                                                                            }),
                                                                                                            pincodeError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                className: "all_error",
                                                                                                                children: pincodeError
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "col-6",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "single-input",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                children: [
                                                                                                                    " ",
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                        className: "astrisk_mark",
                                                                                                                        children: "*"
                                                                                                                    }),
                                                                                                                    "City"
                                                                                                                ]
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Field, {
                                                                                                                type: "text",
                                                                                                                placeholder: "Enter City",
                                                                                                                value: city,
                                                                                                                onChange: handleCityChange
                                                                                                            }),
                                                                                                            cityError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                className: "all_error",
                                                                                                                children: cityError
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "d-flex justify-content-start align-items-center",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                onClick: async (e)=>{
                                                                                                    !isLoanCreat ? await handleCreateApplication(e, values, setFieldValue) : updateLoanApplication(values, setFieldValue);
                                                                                                },
                                                                                                className: "cmn-btn",
                                                                                                children: "Next"
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        })
                                                                    }),
                                                                    values.activeStep === 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "custom_padding",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        class: "row",
                                                                                        children: [
                                                                                            documentOption?.length > 0 && documentOption.map((data, index)=>{
                                                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        class: "my-4 col-lg-6 col-md-6 col-sm-12",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                                                        children: [
                                                                                                                            data?.name,
                                                                                                                            data?.instructions && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                                                className: "instructions",
                                                                                                                                children: [
                                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                                        children: "( "
                                                                                                                                    }),
                                                                                                                                    data?.instructions,
                                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                                        children: ") "
                                                                                                                                    })
                                                                                                                                ]
                                                                                                                            })
                                                                                                                        ]
                                                                                                                    }),
                                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                        class: "input-box-userDashboard ",
                                                                                                                        children: [
                                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                                                type: "file",
                                                                                                                                multiple: true,
                                                                                                                                accept: ".jpg, .jpeg, .png, .bmp, .pdf",
                                                                                                                                ref: aRef,
                                                                                                                                class: "upload-box-userDashboard",
                                                                                                                                onChange: (e)=>handlePanFileChange(data?.name, e, data?.id)
                                                                                                                            }),
                                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                                                className: "upload_btn",
                                                                                                                                onClick: ()=>handleUploadForField(data?.id, data?.name),
                                                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                                                    class: "fa-solid fa-upload"
                                                                                                                                })
                                                                                                                            })
                                                                                                                        ]
                                                                                                                    })
                                                                                                                ]
                                                                                                            }, index),
                                                                                                            docFiles[data?.name]?.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                                                                        children: "Selected files:"
                                                                                                                    }),
                                                                                                                    docFiles[data?.name] && docFiles[data?.name]?.map((file, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                                className: "delete_div",
                                                                                                                                children: [
                                                                                                                                    file && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                                        className: "document_hyper_link",
                                                                                                                                        onClick: ()=>handlePreviewFile(file),
                                                                                                                                        children: file?.name
                                                                                                                                    }),
                                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                                                            class: "delete_button fa-solid fa-xmark",
                                                                                                                                            onClick: ()=>handleRemoveFile(data?.name, index)
                                                                                                                                        })
                                                                                                                                    })
                                                                                                                                ]
                                                                                                                            })
                                                                                                                        }, index))
                                                                                                                ]
                                                                                                            }),
                                                                                                            uploadedFiles[data?.name]?.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                                                                        children: "Uploaded files:"
                                                                                                                    }),
                                                                                                                    uploadedFiles[data?.name]?.map((file, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                                className: "document_hyper_link",
                                                                                                                                onClick: ()=>handlePreviewFile(file?.file),
                                                                                                                                children: file?.name
                                                                                                                            })
                                                                                                                        }, index))
                                                                                                                ]
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                });
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    class: "row",
                                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        class: "my-4 col-lg-12 col-md-12 col-sm-12",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                                                children: "Other Document"
                                                                                                            }),
                                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                className: "d-flex align-items-baseline flex-wrap",
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                        className: "other_doc_input",
                                                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                                            type: "text",
                                                                                                                            placeholder: "Enter document name",
                                                                                                                            value: documentFileName,
                                                                                                                            onChange: (event)=>setDocumentFileName(event.target.value)
                                                                                                                        })
                                                                                                                    }),
                                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                        className: "d-flex",
                                                                                                                        children: [
                                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                                                    type: "file",
                                                                                                                                    accept: ".jpg, .jpeg, .png, .bmp, .pdf",
                                                                                                                                    class: "upload-box-userDashboard",
                                                                                                                                    multiple: true,
                                                                                                                                    onChange: handleFileChange
                                                                                                                                })
                                                                                                                            }),
                                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                                className: "d-flex",
                                                                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                                                    className: "upload_btn",
                                                                                                                                    onClick: handleUploadForOtherDocument,
                                                                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                                                        class: "fa-solid fa-upload"
                                                                                                                                    })
                                                                                                                                })
                                                                                                                            })
                                                                                                                        ]
                                                                                                                    })
                                                                                                                ]
                                                                                                            }),
                                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                                                                children: errorMessage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                    className: "error",
                                                                                                                    children: errorMessage
                                                                                                                })
                                                                                                            }),
                                                                                                            selectedFilesArray.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                                        children: "Selected Files:"
                                                                                                                    }),
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                                                                        children: selectedFilesArray.map((fileObj, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                                    className: "delete_div",
                                                                                                                                    children: [
                                                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                                                                                            children: fileObj.name
                                                                                                                                        }),
                                                                                                                                        " -",
                                                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                                            className: "document_hyper_link",
                                                                                                                                            onClick: ()=>handlePreviewFile(fileObj.file),
                                                                                                                                            children: fileObj.file.name
                                                                                                                                        }),
                                                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                                                            class: "delete_button fa-solid fa-xmark",
                                                                                                                                            onClick: ()=>handleRemoveOtherDocumentFile(fileObj.file)
                                                                                                                                        })
                                                                                                                                    ]
                                                                                                                                })
                                                                                                                            }, index))
                                                                                                                    })
                                                                                                                ]
                                                                                                            }),
                                                                                                            uploadedOtherDocuemnt?.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                children: [
                                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                                                                        children: "Uploaded files:"
                                                                                                                    }),
                                                                                                                    uploadedOtherDocuemnt?.map((file, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                                className: "document_hyper_link",
                                                                                                                                onClick: ()=>handlePreviewFile(file?.file),
                                                                                                                                children: file?.name
                                                                                                                            })
                                                                                                                        }, index))
                                                                                                                ]
                                                                                                            })
                                                                                                        ]
                                                                                                    })
                                                                                                })
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "d-flex justify-content-start align-items-center",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                type: "button",
                                                                                                className: "cmn-btn mr-10",
                                                                                                onClick: ()=>handlePrevious(setFieldValue, values),
                                                                                                children: "Previous"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                                type: "button",
                                                                                                className: "cmn-btn",
                                                                                                onClick: ()=>handleSubmitUploadDoc(setFieldValue),
                                                                                                children: "Submit"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "valid_formate",
                                                                                        children: [
                                                                                            "* Valid File Formats JPG, JPEG, PNG, PDF",
                                                                                            " ",
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                            "* Maximum allowed file size is of 10MB",
                                                                                            " ",
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                            "* After Selecting File, click on upload button"
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        })
                                                                    }),
                                                                    values.activeStep === 3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        class: "main-container d-flex container-fluid p-0",
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            class: "loan-aplication-approver-section",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    class: "img-box",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                        src: "/images/t.jpg",
                                                                                        alt: ""
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "thankYou_button",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                                                        href: "/userDashBoard",
                                                                                        className: "go_to_dashbaord",
                                                                                        children: "Go to My Dashboard"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                    children: [
                                                                                        "We have recevied your",
                                                                                        " ",
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                                                                                            children: [
                                                                                                " ",
                                                                                                selectOptionName ? selectOptionName : "",
                                                                                                " "
                                                                                            ]
                                                                                        }),
                                                                                        " ",
                                                                                        "application"
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    class: "my-4",
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        class: "app-no",
                                                                                        children: [
                                                                                            "Application No.",
                                                                                            " ",
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                children: loanApplicationNumber?.toUpperCase()
                                                                                            }),
                                                                                            " "
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    children: "From here onwards our loan expert will get in touch with you within 24 hours to take this application forward"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    children: "We thank you for choosing Loan Bazaar for your financial needs and would be keen to serve you in the future as well."
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                    class: "in-case",
                                                                                    children: "In case of any queries, feel free to reach out to us on below mentioned details"
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    class: "d-flex justify-content-evenly",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                    class: "free-us",
                                                                                                    children: "Toll Free"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                    class: "number-email",
                                                                                                    children: "1800 - 208 - 8877"
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                                    class: "free-us",
                                                                                                    children: " Write to Us "
                                                                                                }),
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                                                    class: "number-email",
                                                                                                    children: [
                                                                                                        " ",
                                                                                                        "info@loanbazar.com",
                                                                                                        " "
                                                                                                    ]
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApplyForLoan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5994:
/***/ (() => {



/***/ }),

/***/ 483:
/***/ (() => {



/***/ })

};
;
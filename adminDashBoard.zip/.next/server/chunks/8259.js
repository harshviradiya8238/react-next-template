"use strict";
exports.id = 8259;
exports.ids = [8259];
exports.modules = {

/***/ 4112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_notifications__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5974);
/* harmony import */ var react_notifications__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_notifications__WEBPACK_IMPORTED_MODULE_0__);

const Notification = (type, message)=>{
    switch(type){
        case "info":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.info(message);
            break;
        case "success":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.success(message);
            break;
        case "warning":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.warning(message);
            break;
        case "error":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.error(message || "Something Went Wrong");
            break;
        default:
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.info(message);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Notification);


/***/ }),

/***/ 7313:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// const baseUrl = process.env.REACT_APP_BASE_URL;
const baseUrl = `https://loancrmtrn.azurewebsites.net/api`;
const events = (/* unused pure expression or super */ null && ([
    "load",
    "mousemove",
    "mousedown",
    "click",
    "scroll",
    "keypress"
]));
const token =  false ? 0 : "";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: baseUrl,
    timeout: 30000,
    headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        Authorization: token ? `Bearer ${token}` : ""
    },
    validateStatus: (status)=>{
        if (status === 401) {
        // window.location.reload();
        // window.location.href = "/";
        // localStorage.clear();
        }
        return status;
    }
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
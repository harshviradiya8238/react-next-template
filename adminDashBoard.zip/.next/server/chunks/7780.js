"use strict";
exports.id = 7780;
exports.ids = [7780];
exports.modules = {

/***/ 7780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Testimonials)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: ./components/card/TestimonialCard.jsx + 1 modules
var TestimonialCard = __webpack_require__(9128);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
;// CONCATENATED MODULE: ./components/carousel/TestimonialsSlider.jsx





const Next = ({ onClick  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        type: "button",
        className: "slick-arrow slick-prev pull-left",
        onClick: onClick,
        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsChevronLeft, {})
        })
    });
};
const Prev = ({ onClick  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        type: "button",
        className: "slick-arrow slick-next pull-right",
        onClick: onClick,
        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsChevronRight, {})
        })
    });
};
const TestimonialsSlider = ()=>{
    const settings = {
        infinite: true,
        autoplay: false,
        focusOnSelect: false,
        speed: 1000,
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: true,
        prevArrow: /*#__PURE__*/ jsx_runtime_.jsx(Next, {}),
        nextArrow: /*#__PURE__*/ jsx_runtime_.jsx(Prev, {}),
        dots: true,
        dotsClass: "section-dots",
        customPaging: function() {
            return /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "dot",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "string"
                })
            });
        },
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true
                }
            }
        ]
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
        ...settings,
        className: "testimonials-slider",
        children: [
            1,
            2,
            3,
            4
        ].map((itm, i)=>/*#__PURE__*/ jsx_runtime_.jsx(TestimonialCard/* default */.Z, {}, i))
    });
};
/* harmony default export */ const carousel_TestimonialsSlider = (TestimonialsSlider);

;// CONCATENATED MODULE: ./components/common/Testimonials.jsx


const Testimonials = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "testimonials-section",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "sub-title",
                                        children: "Testimonials"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: "Trusted by 2000+ Partners & Customers"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Take a look at our past customers success stories. Our goal is to help you grow"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(carousel_TestimonialsSlider, {})
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const common_Testimonials = (Testimonials);


/***/ })

};
;
"use strict";
exports.id = 4131;
exports.ids = [4131];
exports.modules = {

/***/ 4131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./components/social/Social.jsx
var Social = __webpack_require__(1484);
;// CONCATENATED MODULE: ./public/images/footer-Illu-left.png
/* harmony default export */ const footer_Illu_left = ({"src":"/_next/static/media/footer-Illu-left.e6386b85.png","height":287,"width":286,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABAUlEQVR42mNAB8Hlbxfnd71/yMCwng0umN54ihVE10y9kRZZ+eB/VM2b/1NWvl679eBlTgaGXYd0VDdsFkvMP9aw9+iDKTNX3vvUs/Dxk9nrXlbMW3uPi2HvhYeiIcWXZ+R0fPqz+cD7M2v3vOpZtfv9usVbnuuCje9b8nhF26y7/6snPf4/Z92r/wu3v45adOb9svO3vr08c+NLA0Pb3KdJk1a8ujdtzau7V259mLFt3+P+A5v3tZ69+e3JvtMfToFNia95bJNY/9By4rInW1pnPvg/Y+7l/7PXvHgMlGIGK7CMOiam6HOUr2fhQ6e2uQ8OzN/0+tjHz7/2/f//XxgAmm+ML5tvo5AAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/footer-Illu-right.png
/* harmony default export */ const footer_Illu_right = ({"src":"/_next/static/media/footer-Illu-right.e28d7bc5.png","height":437,"width":372,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AaSu5oAICAh/////AAAAAAABAQEA/Pz8kAcHCHEBoKrbSwkJClAA/gD0AAD/AAECARD+//6x9fTzsAGTmKIaFhP1/tfZu/kGAQoE9iE59yoIIQpaUoP0AX6GqRweHRch/v38/goXIO/kxLKByNPzrrCy0roBdn+kHD47IwLn5uL7DffTEP3v8S/P2gkcLlVdqwGFhIgR3OciSp/aD3dRE/EWTSvgtSMY3rSr/lTBAb7BxRrFyO5k1OEGORUVDeEMCPrvLRngtBHuze8Bvf//AvKpsir57+YHWGkCzQAAIgCijxNS+wADBkJIa3EYzygpAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
// EXTERNAL MODULE: ./public/images/logo.png
var logo = __webpack_require__(8350);
;// CONCATENATED MODULE: ./components/footer/Footer.jsx








const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "footer-section",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container pt-120",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row cus-mar pb-120 justify-content-between wow fadeInUp",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-3 col-lg-3 col-md-4 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            className: "logo",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: logo/* default */.Z,
                                                alt: "logo"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "A modern, technology-first bank built for you and your growing business."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "social-link d-flex align-items-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Social/* default */.Z, {
                                                items: [
                                                    [
                                                        fa_.FaFacebookF,
                                                        "/"
                                                    ],
                                                    [
                                                        fa_.FaTwitter,
                                                        "/"
                                                    ],
                                                    [
                                                        fa_.FaLinkedinIn,
                                                        "/"
                                                    ],
                                                    [
                                                        fa_.FaInstagram,
                                                        "/"
                                                    ]
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-2 col-lg-2 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Company"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "footer-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/about",
                                                        children: "About Us"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/about",
                                                        children: "Awards"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/career-single",
                                                        children: "Careers"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-2 col-lg-2 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Useful Links"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "footer-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/product",
                                                        children: "Products"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/business-loan",
                                                        children: "Business Loan"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/affiliate",
                                                        children: "Affiliate Program"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/blog-list",
                                                        children: "Blog"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-2 col-lg-2 col-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Support"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "footer-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "mailto:support@bankio",
                                                        children: "Support@bankio"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/contact",
                                                        children: "Contact Us"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/faqs",
                                                        children: "FAQ"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-3 col-8",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-box",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            children: "Subscribe"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "text",
                                                        placeholder: "Email address",
                                                        required: true
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "cmn-btn",
                                                        children: "Subscribe"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Get the latest updates via email. Any time you may unsubscribe"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "footer-bottom",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "left",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                " ",
                                                "Copyright \xa9 ",
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "index",
                                                    children: "Bankio"
                                                }),
                                                " | Designed by",
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "https://themeforest.net/user/pixelaxis",
                                                    children: "PIXELAXIS"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "right",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: "/privacy-policy",
                                                className: "cus-bor",
                                                children: [
                                                    "Privacy",
                                                    " "
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "terms-conditions",
                                                children: "Terms & Condition "
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "img-area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: footer_Illu_left,
                        className: "left",
                        alt: "Images"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: footer_Illu_right,
                        className: "right",
                        alt: "Images"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const footer_Footer = (Footer);


/***/ }),

/***/ 1484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const Social = ({ items =[]  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: items?.map(([Item, url], i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: url,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {})
            }, i))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Social);


/***/ })

};
;
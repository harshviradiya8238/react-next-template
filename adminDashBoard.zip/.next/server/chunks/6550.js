"use strict";
exports.id = 6550;
exports.ids = [6550];
exports.modules = {

/***/ 6550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ carLoan_HowItWork)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/common/SingleBox.jsx
var SingleBox = __webpack_require__(3039);
// EXTERNAL MODULE: ./public/images/icon/get-loan-1.png
var get_loan_1 = __webpack_require__(7178);
// EXTERNAL MODULE: ./public/images/icon/get-loan-2.png
var get_loan_2 = __webpack_require__(7034);
// EXTERNAL MODULE: ./public/images/icon/get-loan-3.png
var get_loan_3 = __webpack_require__(3987);
// EXTERNAL MODULE: ./public/images/icon/get-loan-4.png
var get_loan_4 = __webpack_require__(8838);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-1.png
var loan_feature_1 = __webpack_require__(3473);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-2.png
var loan_feature_2 = __webpack_require__(5425);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-3.png
var loan_feature_3 = __webpack_require__(2659);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-4.png
var loan_feature_4 = __webpack_require__(6530);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-5.png
var loan_feature_5 = __webpack_require__(207);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-6.png
var loan_feature_6 = __webpack_require__(1174);
;// CONCATENATED MODULE: ./components/carLoan/carLoanData.js










const get_loan_data = [
    {
        id: 1,
        icon: loan_feature_1/* default */.Z,
        title: "Simple Application Process",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 2,
        icon: loan_feature_2/* default */.Z,
        title: "No credit check",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 3,
        icon: loan_feature_3/* default */.Z,
        title: "No employment requiered",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 4,
        icon: loan_feature_4/* default */.Z,
        title: "Secure loan",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 5,
        icon: loan_feature_5/* default */.Z,
        title: "Fast approval",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 6,
        icon: loan_feature_6/* default */.Z,
        title: "Cash within minutes",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    }
];
const how_it_work_data = [
    {
        id: 1,
        icon: get_loan_1/* default */.Z,
        title: "1. Fill the form",
        desc: "Fill basic information for us to get in touch with you."
    },
    {
        id: 2,
        icon: get_loan_2/* default */.Z,
        title: "2. Get pre-qualified",
        desc: "Verify your ID and get on a quick video call with a loan specialist."
    },
    {
        id: 3,
        icon: get_loan_3/* default */.Z,
        title: "3. Send documents",
        desc: " Upload your documents on the Bankio app and get approved in"
    },
    {
        id: 4,
        icon: get_loan_4/* default */.Z,
        title: "4. Get a New Car",
        desc: "Make smart spending decisions on the spot. Our budgeting too"
    }
];

;// CONCATENATED MODULE: ./components/carLoan/HowItWork.jsx



const HowItWork = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "account-feature get-loan",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-9",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "sub-title",
                                        children: "A Better Way to Get Loan"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: "How it works"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "It's easier than you think. Follow the following simple easy steps"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row cus-mar",
                        children: how_it_work_data.map((singleData)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SingleBox/* default */.Z, {
                                    icon: singleData.icon,
                                    title: singleData.title,
                                    desc: singleData.desc
                                })
                            }, singleData.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const carLoan_HowItWork = (HowItWork);


/***/ })

};
;
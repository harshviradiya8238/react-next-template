"use strict";
exports.id = 279;
exports.ids = [279];
exports.modules = {

/***/ 279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Benefits)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-1.png
var loan_feature_1 = __webpack_require__(3473);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-2.png
var loan_feature_2 = __webpack_require__(5425);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-3.png
var loan_feature_3 = __webpack_require__(2659);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-4.png
var loan_feature_4 = __webpack_require__(6530);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-5.png
var loan_feature_5 = __webpack_require__(207);
// EXTERNAL MODULE: ./public/images/icon/loan-feature-6.png
var loan_feature_6 = __webpack_require__(1174);
;// CONCATENATED MODULE: ./data/getLoanData.js






const get_loan_data = [
    {
        id: 1,
        icon: loan_feature_1/* default */.Z,
        title: "Simple Application Process",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 2,
        icon: loan_feature_2/* default */.Z,
        title: "No credit check",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 3,
        icon: loan_feature_3/* default */.Z,
        title: "No employment requiered",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 4,
        icon: loan_feature_4/* default */.Z,
        title: "Secure loan",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 5,
        icon: loan_feature_5/* default */.Z,
        title: "Fast approval",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    },
    {
        id: 6,
        icon: loan_feature_6/* default */.Z,
        title: "Cash within minutes",
        desc: "Lorem ipsum dolor sit amet, consectetur adiet libero."
    }
];
/* harmony default export */ const getLoanData = (get_loan_data);

// EXTERNAL MODULE: ./components/common/SingleBox.jsx
var SingleBox = __webpack_require__(3039);
;// CONCATENATED MODULE: ./components/common/Benefits.jsx



const Benefits = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "account-feature loan-feature",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-8",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "sub-title",
                                        children: "Why Bankio is a great financing option for you."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: "Great benefits from Bankio"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Bankio CarLoan offers you the freedom to choose any vehicle on a fixed mark-up rate facility to suit your personal requirements​"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row cus-mar",
                        children: getLoanData.map((singleData)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4 col-md-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SingleBox/* default */.Z, {
                                    icon: singleData.icon,
                                    title: singleData.title,
                                    desc: singleData.desc
                                })
                            }, singleData.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const common_Benefits = (Benefits);


/***/ })

};
;
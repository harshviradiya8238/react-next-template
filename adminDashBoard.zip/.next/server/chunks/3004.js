"use strict";
exports.id = 3004;
exports.ids = [3004];
exports.modules = {

/***/ 1527:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-right.e355c5aa.png","height":14,"width":15,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAiUlEQVR42mMAAUmfvYwgDGVzgGgom4kBHUj57RGU9N1TIOy5mxsi4LmHDaiSU8p7DyeQ5oYqMpf03dso6rlbmEHKZ4+fpPfeciBdCFRUBFRUDqQjpHz2bgIq6gOpZgMq4JTyQZgg6Q0xQTpgvzCmG7z3At2wr0AqcD9QMRRIeiP5wnc/whe++5gAI3cvjr9xUSMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 1484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const Social = ({ items =[]  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: items?.map(([Item, url], i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: url,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {})
            }, i))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Social);


/***/ }),

/***/ 8339:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ data_blogData)
});

;// CONCATENATED MODULE: ./public/images/blog-post-1.png
/* harmony default export */ const blog_post_1 = ({"src":"/_next/static/media/blog-post-1.a985b08b.png","height":220,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAkElEQVR42iXNzQqCQAAA4X38nqNjEOWhWxB5kSK0DkHI1mZaspimq1ELsdPfZU4fjLganNEXtoEiVqBijdYPyhqq2jnxAbS5IpUamcJonOH7+g8ah/gmL8BULYG3ot+bMhie2B8tdQfC3GGxLJFRQhaF5EmBNymZzW90TxBNhws3Z1RmWe8s8eGFVJaq+S3cGz7lkmY0WmO0AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/images/blog-post-2.png
/* harmony default export */ const blog_post_2 = ({"src":"/_next/static/media/blog-post-2.96e16e32.png","height":220,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAhUlEQVR42h3N2wqCQABFUf//wwqCfMtukI7kqONchUjUmd3Q2+GwYRUukFxIKB2pxUotN0Te+cP4lArpYJo29MtTiZm6+3KWK40DE6C4dguiUtjxw+nQ8OgjF7nQPluUjRTaRG6lRnm49zt+hs7sHMs3/bjlIDuDSVifssvfHlyitWAD6QeAAZarZYIlEAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/images/blog-post-3.png
/* harmony default export */ const blog_post_3 = ({"src":"/_next/static/media/blog-post-3.e74af22a.png","height":220,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAkUlEQVR42h3MOwuCUABAYf//Vi0F0drcHBG9NENq0CVEyRyy0uvVm9lD7omcz+EzRIHOpKasIDg3nBJYOYpj+EJVaOMf8xKu6ZfpMsKdWYh7jed/SNKGdpAKwljRGSw4dHvstxui5I2QYOQFJLcnc8vFtD36nTGj4QT5ACF1K2hRaOJLzdoO2JkejuUjSsik1j87x5EtoyGKwAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/images/blog-post-4.png
/* harmony default export */ const blog_post_4 = ({"src":"/_next/static/media/blog-post-4.fe193ad3.png","height":220,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAApklEQVR4nAWAPQsBARiAn/dkODo2RD47wy0Gu8nI4HdY/QJ/xGo1GCw+BimLGYVTlEJdCIV7JVfP90WQnw+osl49sYshLMvg9VIV7676+4L3gIChnCcjhjubaj1GIW8ix8tXb+6eoH5IOEXCxonl1sSpXVkMskin29f5yqWSsajXGkRjEQ6zOe1emlYzjgyna3/juhI0I+RSGZKBA+PJm1K1jGOb+gdfokLmIM8aGAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/images/blog-post-5.png
/* harmony default export */ const blog_post_5 = ({"src":"/_next/static/media/blog-post-5.0274d5f5.png","height":220,"width":350,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAn0lEQVR42h2NOQ6CUABE/yk8infwNpYmxnO4VBTGpbDRzsIFYyKJ0cLOggIDAQLI4sKW/0SKqWbmPRElSMcrmCxvjKZnVM3A8UqCCP6deMawVnVEs09DdFDGR3bag1l1MO0UYbkZrfaK3mBPd7thvtA4VIPTxcL1S2qCbiSkWcHdDhgqVywz5JtTa4QfShm/4VUlz8H3PnhBRhCDH0r5A3fNi1MVodm6AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./data/blogData.js





const blogData = [
    {
        id: 1,
        title: "How Do Unsecured Homeowner Loans Work?",
        date: "December 19,2021",
        desc: "There are usually two kinds of loans: secured loans, and unsecured loans.",
        type: "Loan",
        img: blog_post_1
    },
    {
        id: 2,
        title: "Choosing the Right Business Loan For Your Company",
        date: "December 19,2021",
        desc: "Operating a business takes money and just about everyone has heard the expression..",
        type: "Loan",
        img: blog_post_2
    },
    {
        id: 3,
        title: "Personal Loans Are Here To Finance Your Dreams.",
        date: "December 19,2021",
        desc: "The secured personal loans are offered based on a collateral security such as car, house...",
        type: "Loan",
        img: blog_post_3
    },
    {
        id: 4,
        title: "How to convert credit card outstanding into EMIs?",
        date: "December 19,2021",
        desc: "There are usually two kinds of loans: secured loans, and unsecured loans.",
        type: "Loan",
        img: blog_post_4
    },
    {
        id: 4,
        title: "Everthing you need to know about home loan",
        date: "December 19,2021",
        desc: "There are usually two kinds of loans: secured loans, and unsecured loans.",
        type: "Loan",
        img: blog_post_5
    }
];
/* harmony default export */ const data_blogData = (blogData);


/***/ })

};
;
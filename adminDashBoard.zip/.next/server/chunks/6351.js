exports.id = 6351;
exports.ids = [6351];
exports.modules = {

/***/ 6385:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ready_Ready)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./public/images/get-start.png
/* harmony default export */ const get_start = ({"src":"/_next/static/media/get-start.8356bb76.png","height":380,"width":469,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAsElEQVR42mNAAwJALAViPD2xxfTu8V2+DKI/VjDOOrGcFSQ4u29S+9bly96D2HvOP8w6ceFWIYr2V7cuWL28ffl9+4n3xgwH/q9n2PlfgoHh7yophh/rVRlA4MC/qZ7Hfv1nOPT/I8PB/x5gMcH/yyICn2/+Ma3sz/X+5t//fVf++29+/PtRsOTe/8wMp38/4bv27mHD1Ipf0xdl/15f2vx35bUTUw78v8MgwsDAwAAAGT1TuhNE4tUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./components/ready/Ready.jsx




const Ready = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "get-start wow fadeInUp",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-60 pb-120",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "get-content",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section-text",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "title",
                                        children: "Ready to get started?"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "It only takes a few minutes to register your FREE Bankio account."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: get_start,
                                alt: "get start"
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const ready_Ready = (Ready);


/***/ }),

/***/ 9090:
/***/ (() => {



/***/ })

};
;
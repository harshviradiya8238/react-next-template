"use strict";
exports.id = 21;
exports.ids = [21];
exports.modules = {

/***/ 1527:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-right.e355c5aa.png","height":14,"width":15,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAiUlEQVR42mMAAUmfvYwgDGVzgGgom4kBHUj57RGU9N1TIOy5mxsi4LmHDaiSU8p7DyeQ5oYqMpf03dso6rlbmEHKZ4+fpPfeciBdCFRUBFRUDqQjpHz2bgIq6gOpZgMq4JTyQZgg6Q0xQTpgvzCmG7z3At2wr0AqcD9QMRRIeiP5wnc/whe++5gAI3cvjr9xUSMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 3612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/business.844b84ec.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAmklEQVR42k2OMQoCMRBF09ssmKgzaiEINloraLGgoMYEGxVBb+AVTc7mC+zKBh7/z/xhJqZ9EtISPEQYdwMnMSn6QTfoEd4Svxa1ZWBNMABRmhqTxSsMS2Y05Ml/G57mqK015nnZcIUeoaAvuEvMfbSCh6F4Ei5g1nzwhJ/CiuxWBjz3HPcdWsMOX6FasnKiBt+whwNc4CwhbX857kp3Lh3z1QAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/checking.b74e4c88.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAg0lEQVR42o3PSwrCMBCA4QHtsjvFJIuACqWCG134QAUp7arJGXrRpmfrP9Cu24EPMg+GiawKF9LWwsW0UUKQFzYMV3184SdnlDjZOHzQCVN/Cm/sYUxIN9OmA80SzTzwRO5in+lqeJp31ELywxEeBV640HygEg09EBnr9cC5tkO++MMRobs28Wja1jYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/savings.6ba857bf.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAaVBMVEUZUr4YUL4ZTr0ZTb0ZTL4ZTL0ZTLwZS70ZTb0ZTL0YS70ZTb0ZTL0ZTL0ZTL0ZTb0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL1hM+euAAAAI3RSTlMAAAAAAAAAAAEBAgQECAwPEBESExQXGBobHCMlJistMDI1SG6F8lcAAABBSURBVHjaBYAFEoAgAATPWBRbsQD7/490RIHZB6xovP8eJLor3O+eKjl6MrM6VbHGsE2iPt28RGSzMbjYIkqA3P6DNQN3Ogg3XQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5058:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BusinessSolutions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./public/images/icon/arrow-right.png
var arrow_right = __webpack_require__(1527);
;// CONCATENATED MODULE: ./components/cards/BusinessSolutionsCard.jsx




const BusinessSolutionsCard = ({ singleBusiness  })=>{
    const { title , icon , desc , link  } = singleBusiness;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "single-box text-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "thumb d-flex justify-content-center align-items-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: icon,
                    alt: "checking"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: desc
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: link,
                        className: "btn-arrow",
                        children: [
                            "Apply for Loan",
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: arrow_right/* default */.Z,
                                alt: "arrow"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const cards_BusinessSolutionsCard = (BusinessSolutionsCard);

// EXTERNAL MODULE: ./components/account/accountData.js + 1 modules
var accountData = __webpack_require__(433);
;// CONCATENATED MODULE: ./components/account/BusinessSolutions.jsx



const OurServices = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "solutions-business account",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "sub-title",
                                        children: "Apply Loan from anywhere in the world"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: "Solutions for Every Business Need"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Power up your business with a full-stack online bank account that fits your needs"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row cus-mar",
                        children: accountData/* business_solutions_data.map */.c.map((singleBusiness)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4 col-md-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(cards_BusinessSolutionsCard, {
                                    singleBusiness: singleBusiness
                                })
                            }, singleBusiness.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const BusinessSolutions = (OurServices);


/***/ }),

/***/ 5751:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_SingleBox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3039);
/* harmony import */ var _accountData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(433);



const OpenAccount = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "account-feature",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-9",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "sub-title",
                                        children: "Open your account from anywhere in the world"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "title",
                                        children: "An account, designed for you"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Power up your business and personal life with a full-stack online bank account that fits your needs."
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row cus-mar",
                        children: _accountData__WEBPACK_IMPORTED_MODULE_2__/* .open_account_data.map */ .n.map((singleData)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_SingleBox__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    icon: singleData.icon,
                                    title: singleData.title,
                                    desc: singleData.desc
                                })
                            }, singleData.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OpenAccount);


/***/ }),

/***/ 433:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "c": () => (/* binding */ business_solutions_data),
  "n": () => (/* binding */ open_account_data)
});

// EXTERNAL MODULE: ./public/images/icon/business.png
var business = __webpack_require__(3612);
// EXTERNAL MODULE: ./public/images/icon/checking.png
var checking = __webpack_require__(9386);
// EXTERNAL MODULE: ./public/images/icon/savings.png
var savings = __webpack_require__(3681);
;// CONCATENATED MODULE: ./public/images/icon/account-feature-1.png
/* harmony default export */ const account_feature_1 = ({"src":"/_next/static/media/account-feature-1.dd7008d5.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAjUlEQVR42k3OWwrCMBCF4VFQERSfqhmR4gWrVkWpyzBZR7vIJmvrP6UPDXwQOCczEfVxCsELH/xwhmAio8INDWoc0Gd9C4I3MuzwGE8wR1ycj3sN8PHuQsqFY6FTn67IuX/xxElDspVbK5RYoKBkayoQpiWlUizASgMIBhusUQh758OrDPYHtdGo9N/OOiyGTjB1GwGKAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/images/icon/account-feature-2.png
var account_feature_2 = __webpack_require__(911);
// EXTERNAL MODULE: ./public/images/icon/account-feature-3.png
var account_feature_3 = __webpack_require__(6199);
;// CONCATENATED MODULE: ./components/account/accountData.js






const business_solutions_data = [
    {
        id: 1,
        title: "Home Loan",
        icon: checking/* default */.Z,
        desc: "Choose from our checking options that allow you to earn interest and easily manage your account and make dream come true.",
        link: "/loanapplication"
    },
    {
        id: 2,
        title: "Personal Loan",
        icon: savings/* default */.Z,
        desc: "Save for your goals and watch your money grow with a CD, a money market account, a savings account.Your future starts now.",
        link: "/loanapplication"
    },
    {
        id: 3,
        title: "Car Loan",
        icon: business/* default */.Z,
        desc: "Take charge of your business banking with a business bank account. Services including virtual cards, team management and more.",
        link: "/loanapplication"
    }
];
const open_account_data = [
    {
        id: 1,
        icon: account_feature_1,
        title: "No Minimum Balance Required",
        desc: "Taking the first step towards your dreams should be a breeze, not a burden."
    },
    {
        id: 2,
        icon: account_feature_2/* default */.Z,
        title: "No Monthly Account Fees",
        desc: "So that every month, you can focus on investing in your ambitions"
    },
    {
        id: 3,
        icon: account_feature_3/* default */.Z,
        title: "No SSN Needed",
        desc: "All we need is basic information about you, your visa and passport"
    }
];


/***/ })

};
;
"use strict";
exports.id = 1526;
exports.ids = [1526];
exports.modules = {

/***/ 1526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ faq_Faq)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./data/faqData.js
const faqData = [
    {
        id: 1,
        question: "How do I locate the nearesty branch or ATM?",
        answer: "If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120."
    },
    {
        id: 2,
        question: "What do I do if I lose my card or it gets stolen?",
        answer: "If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120."
    },
    {
        id: 3,
        question: "What is your customer service number?",
        answer: "If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120."
    },
    {
        id: 4,
        question: "How do I reset my pin?",
        answer: "If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120."
    },
    {
        id: 5,
        question: "What is required to use Digital Banking?",
        answer: "If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120."
    },
    {
        id: 6,
        question: "Is digital banking secure?",
        answer: "If your card is missing, let us know immediately. We’ll block your card right away send over a new one on the same day.To report a lost or stolen card, call us at (406) 555-0120."
    }
];
/* harmony default export */ const data_faqData = (faqData);

;// CONCATENATED MODULE: ./components/faq/Faq.jsx



const Faq = ({ cls =""  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: `faqs-section ${cls}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row d-flex justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "sub-title",
                                        children: "If you have question,we have answer"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: "Frequently asked questions"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            "Get answers to all questions you have and boost your knowledge so you can save, invest and spend smarter.",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/faqs",
                                                children: "See all questions here!"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row d-flex justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-8",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "faq-box wow fadeInUp",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "accordion",
                                    id: "accordionExample",
                                    children: data_faqData.map((itm, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "accordion-item",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                    className: "accordion-header",
                                                    id: `heading${i}`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "accordion-button collapsed",
                                                        type: "button",
                                                        "data-bs-toggle": "collapse",
                                                        "data-bs-target": `#collapse${i}`,
                                                        "aria-expanded": "false",
                                                        "aria-controls": `collapse${i}`,
                                                        children: itm.question
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    id: `collapse${i}`,
                                                    className: "accordion-collapse collapse",
                                                    "aria-labelledby": `heading${i}`,
                                                    "data-bs-parent": "#accordionExample",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "accordion-body",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: itm.answer
                                                        })
                                                    })
                                                })
                                            ]
                                        }, itm.id))
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const faq_Faq = (Faq);


/***/ })

};
;
"use strict";
exports.id = 5778;
exports.ids = [5778];
exports.modules = {

/***/ 1290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/check.739d0fb0.png","height":18,"width":18,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAT0lEQVR42mNAgH9MQAIB/jEDMTeQBHMY/7ECSdt//RAOE1jQ/N+6fxIQ+cZ/Zv90/234JwzWCCSk/q39t/6fEJDFAjX7n9g/UbAswjoEFwC08iMV62MQwgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_LoanCounter)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/images/counter-Illus.png
/* harmony default export */ const counter_Illus = ({"src":"/_next/static/media/counter-Illus.5121033d.png","height":534,"width":638,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA3ElEQVR42mPYWcHAxMDAwBAZve5YXviEdQwMDAwP3v44+/LD9yYGZDApIerz3FCGnf///+e/8/rX/yfvvm9AyGZ81ZmW1fGyLXvhVgYGBob/v98o////nx0sp3TwrTPDhHf/7UOP/VfOu/Q/ccqFM4sYGKwZGBnEnFNdNBkmt0y8Wte05X9vZPGfkJzj3+r7dvxfkSqaxpDlb6qfaBXMsCpZeX1z5LwXtuF3/jOEfNi/OkG1fUpGcDJDrKOmfryVIwMYeH85yeD16j+798tLEDcxsHmGpU70Ds5QAABtYVxbNrmwDwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./components/common/LoanCounter.jsx




const LoanCounter = ({ btnText , link , title , loans_given , customers_served , countries  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "counter-educations",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container wow fadeInUp",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row d-flex align-items-end justify-content-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-5",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "img-area",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: counter_Illus,
                                    className: "max-un",
                                    alt: "image"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-lg-7 pt-120 pb-120",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "section-text",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: title
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "counter-area mb-60 d-flex align-items-center justify-content-between",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "single",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "counter",
                                                            children: loans_given
                                                        }),
                                                        "M+"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Loans Given"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "single",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "counter",
                                                            children: customers_served
                                                        }),
                                                        "+"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Customers Served"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "single",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    className: "counter",
                                                    children: countries
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Countries"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "btn-area",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: link,
                                        className: "cmn-btn",
                                        children: btnText
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const common_LoanCounter = (LoanCounter);


/***/ })

};
;
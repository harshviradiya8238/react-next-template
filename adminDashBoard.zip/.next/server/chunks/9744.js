exports.id = 9744;
exports.ids = [9744];
exports.modules = {

/***/ 9128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ card_TestimonialCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./public/images/testimonials-image-1.png
/* harmony default export */ const testimonials_image_1 = ({"src":"/_next/static/media/testimonials-image-1.052afa92.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAO0lEQVR42k2LQQrAIAwE9/9Hk/bYPsMWJ/FriiC4sDCHGdHW0PwikUQk6PervHZXVTd7in+iE9k55J0PV4ctFpEZzLcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/card/TestimonialCard.jsx




const TestimonialCard = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "single-slide",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "single",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "review-area d-flex gap-1",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillStarFill, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillStarFill, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillStarFill, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillStarFill, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "blank",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillStarFill, {})
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "xlr",
                    children: "Sed arcu tortor, feugiat sit amet accumsan ac, maximus quis quam.vitae Integer ultrices elit."
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "profile-area d-flex align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "img-area",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: testimonials_image_1,
                                alt: "image"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            children: "Ben Mason"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const card_TestimonialCard = (TestimonialCard);


/***/ }),

/***/ 8278:
/***/ (() => {



/***/ })

};
;
"use strict";
exports.id = 763;
exports.ids = [763];
exports.modules = {

/***/ 1290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/check.739d0fb0.png","height":18,"width":18,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAT0lEQVR42mNAgH9MQAIB/jEDMTeQBHMY/7ECSdt//RAOE1jQ/N+6fxIQ+cZ/Zv90/234JwzWCCSk/q39t/6fEJDFAjX7n9g/UbAswjoEFwC08iMV62MQwgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ common_Planning)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/images/icon/loan-1.png
/* harmony default export */ const loan_1 = ({"src":"/_next/static/media/loan-1.a08ca70f.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAmUlEQVR42k2OzQqCQBSFJ2nVqkVJIxUUSEW06Y8CF9KiTWNB7aTnFATHZ/NzvKIXPg7MOXfuUdpYTzHoCC7whLR5K/Aa04c33LQpp+gf5s6UwFhCX0hhC9fJKxu0gRBitu/oDz46sREaKbm7kw4b2X4QPsGyDqy6U4UPC4wY1v0OB/lpD0e3yaBebZ6DxIYSHM5M7ooFpnRaAZMrQNDqvZF3AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-11.png
/* harmony default export */ const loan_11 = ({"src":"/_next/static/media/loan-11.fcc71a4a.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZElEQVR42iXNMQqCAAAF0G80ObXkVEKBZERLZRQ4SENjQW3S/Y/xaPAC78VMlDpPo5hFVF5uln5WErFQ+Ri1roqIxuDu663XR2evtNN6OKtjY3LWBluJOOocnNTTctGIuUIU8gdhn0e0d2MGHwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-2.png
/* harmony default export */ const loan_2 = ({"src":"/_next/static/media/loan-2.6b00852d.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR42jXN2wrCMAyA4Tm8FmSgW9VdDDdkoIg4GILHgaC04IV4Kz6mYPts/tkh8JE0SVtPItK2jIydKG3HyriA8w6DbrhHgTmyUNuUvGr7Q1mocMVDNcMD7nhh5tFMKN54RtoV5DM+qFDKCxcsgpvzyRlyHJV2ay7EshB7TVD/RpgyOCHp+rK0RIEcm/omQfZluFXGpu1iP9TfntR8Uec//sxGqi+aDlEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-22.png
/* harmony default export */ const loan_22 = ({"src":"/_next/static/media/loan-22.33ea29c5.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZUlEQVR42gXAPQsBAQAG4JfMSooBN8hJVyS5utT5ujKYDLLK//8PT4pozEyNnQwlWrWVtdJOaxSdh5fS2dPHIpa+3mo3P50m7jb61ioXe0UUIibmrpYSsVWrHBSiH0elGOiJnvwB2FRI+wQXO5MAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-3.png
/* harmony default export */ const loan_3 = ({"src":"/_next/static/media/loan-3.693a1733.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEUiYsMbTr4ZTb0aTL0ZTL4ZTL0ZS7wZTbwZTL0ZTL0YTL4ZTLwaTbwaTL0ZTL0ZTb0ZTL4ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL3vm5jIAAAAKXRSTlMAAAAAAAAAAQECAgMHCw4PDxseHyEjJScpLi8wNDU4OT1LTE1PUVNVWp8gsPEAAABGSURBVHjaFcEHEkAwAATAEzmidyFK9Pj/C41d8CdJKJloHYcKZPM+NX3knb3c2mYYDm3G3m0Qwb3YvZwRsZhMWp2gEiThfY0VBB/ORpt7AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-33.png
/* harmony default export */ const loan_33 = ({"src":"/_next/static/media/loan-33.cbf5c349.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAY0lEQVR42mXNMQrCYBiD4e+vg4NgDyAoIlJcrIOCHTyBikjp0vuf46Gl/1JoQoaEwBsLSWNWqtGFJOXxoNfa57J10vjpPB1twsVHpXZ11nnl199D4610D0WE0k1tbec7cebUAfhdLz6heoi+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-4.png
/* harmony default export */ const loan_4 = ({"src":"/_next/static/media/loan-4.c948ead0.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAk0lEQVR42jXPvQrCMBSG4RQUwcl/mwwuoqBQ20WU0EV0EY+ggoj3qlm8Md9TksBDDl++BGKsfDOYqGfls2IfpUyXDgOUeEDwRAWXCrtcQhemf/5lMNNLaJHXqVCjwBp3lFhA9HCJN17wOGKOiZWwb56HxxiVu4aOk9BmHsJrYRtLJ3hsUKDCTAs5bjhYbkMz4+I3//1fTgGe5w8/AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/loan-44.png
/* harmony default export */ const loan_44 = ({"src":"/_next/static/media/loan-44.397c4c28.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAaUlEQVR42i3KzQoBURiA4U/RlJX8JQsbUdSY2ejoNBuxnAVKcv/38eQsPMu3NwyiMHEwj6Iw1XjpvbXWJUjGEcppqCtBp3b01Njpw97XR3aztXQJSbbQqozM5HCW3GUntdYmrDxcVfH3Az7+O4OZO1OiAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./data/planningData.js








const planning_data = [
    {
        id: 1,
        icon1: loan_1,
        icon2: loan_11,
        title: "Home Loans",
        dsc_list: [
            "Lowest interest rates",
            "Fast Loan Processing"
        ]
    },
    {
        id: 2,
        icon1: loan_2,
        icon2: loan_22,
        title: "Car Loans",
        dsc_list: [
            "Competitive rates",
            "Quick Easy"
        ]
    },
    {
        id: 3,
        icon1: loan_3,
        icon2: loan_33,
        title: "Education Loans",
        dsc_list: [
            "Pay back conveniently",
            "Fast Loan Processing"
        ]
    },
    {
        id: 4,
        icon1: loan_4,
        icon2: loan_44,
        title: "Business Loans",
        dsc_list: [
            "Easy Approvals",
            "Full Assistance"
        ]
    }
];
/* harmony default export */ const planningData = (planning_data);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/images/icon/check.png
var check = __webpack_require__(1290);
;// CONCATENATED MODULE: ./components/cards/PlaningCard.jsx




const PlaningCard = ({ singlePlanning  })=>{
    const { icon1 , icon2 , title , dsc_list  } = singlePlanning;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "plan-box",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "thumb",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: icon1,
                        alt: "icon",
                        className: "active"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: icon2,
                        alt: "icon",
                        className: "alt"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/register",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                    children: title
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "list",
                children: dsc_list?.map((itm, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "list-item d-flex align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "check d-flex align-items-center justify-content-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: check/* default */.Z,
                                    alt: "icon"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: itm
                            })
                        ]
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const cards_PlaningCard = (PlaningCard);

;// CONCATENATED MODULE: ./components/common/Planning.jsx




const Planning = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "financial-planning",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container wow fadeInUp",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row d-flex justify-content-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-xl-6 col-lg-5",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "section-text",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "sub-title",
                                            children: "Financial Planning"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "title",
                                            children: "Let's plan your finances the right way"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Lending that doesn't weigh you down.We know how hard is it to start something new, that’s why we have the perfect plan for you."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/register",
                                    className: "cmn-btn",
                                    children: "Apply for loan"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-7",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row cus-mar",
                                children: planningData.map((singlePlanning)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6 col-sm-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(cards_PlaningCard, {
                                            singlePlanning: singlePlanning
                                        })
                                    }, singlePlanning.id))
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const common_Planning = (Planning);


/***/ })

};
;
"use strict";
exports.id = 1432;
exports.ids = [1432];
exports.modules = {

/***/ 3473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loan-feature-1.b47d6e01.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAn0lEQVR42k2O7QqCMBSGi4iwCP+IbqsoIrIpFXoZut1wuXVrPcsGDh7Ox/vunDOLTxp3kta1kIZ6IvgC8Qk32EOjjKtl79ajwfqWZiim03IMeTRo2b2Xsh80ZMK4LYYrFNFQCTMkwg6KZga16F8LbtHkx98Edm5oHMafPiUqakleBcNDGb+CBCGHBvFCFFCGg87CujvU//070FDK7jP/AgR/QhOUduaOAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loan-feature-2.e4f431cc.png","height":50,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAxklEQVR42mOAAbWAfXL+mYd1QOxnb39WfPj29xoDGDBvYVTw26cTWXhMDsQ9duF15Z0nX/9/+/3fmQEEFPz2KkYXH5cFse89/xbz8MX3/+evv01mgAG35EO6YMln3yJBOoHACchlz2s4JQNTw3X84uuMB0Cdv///dwcJRBUe02Fw3sPJAAK3Hn3xAOL/tx5+SgfxIwqO6op577VngIHLdz4avP/6FyTAGpxzRFXAay+vpPdeHiDWlfDax8yACwAVCEl67xUFAMPmWitNyEvoAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loan-feature-3.1832ed45.png","height":50,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoklEQVR42i3EvS6DYRwH0PN7PCKEwUdpY2Gwuwcjl2vtbZiMaNpII00qqej718FwTiZPU4DTYhI+sQCk4wxjjFLexB2uMJ89Pyw6bjCnlmLANxlwPX6crlqq1kOzqOTw31HFpvgYbH96Ja1td8uK+q20lLoM53vZO+ihUREnyoa6iMzQqVEraki7HSQ7Hah7aol1V17CvgiqKu9JfeG40l7/AMBGQ0sLrScfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loan-feature-4.ec47d563.png","height":50,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEUYUboWULkZTb0ZTL0ZTLwaS70YTLwZTL0YTLwZS7wZTL0ZTL0aTL0ZTL0ZTLwZTL0aS7wZTL0aS70aS7wZTL0ZTb4ZTb0ZTL0ZTL0YTb0aS70ZS70YTb0ZTL0ZTL0aS70ZS70YTb0ZTL0ZTL0ZTL0ZTL0aTL4ZS70aTL0ZS71brHe3AAAAKnRSTlMAAAAAAAAAAQUFCwwQERMUFBUZGRwdHR0eJCQkJScoKCgpKSosLTAwNjb5XkaTAAAAR0lEQVR42gVABxZAIAD9mmZCFBLZ7n9BDyaO3vto8M3WOTu9eDqltWpvbOCM8WTFklMpaRFQ7lQIelQgQ0iz0BNIUp9XQ+QPuoUEhxpKi5oAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 207:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loan-feature-5.ebda64a8.png","height":50,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEUhU7wdTb4aTr4ZTb0ZTL4aTLsZTL0YTL0ZTL0ZTb0YTb4YTb0ZTL0ZTL0YTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTL0ZTb0ZTL0ZTL0ZTb0ZTL0ZTL0ZTL0ZTb0ZTL0ZTL0ZTL0aS70ZS70ZTL0ZTb0ZTL4ZTL0ZTL3Ee877AAAAKHRSTlMAAAAAAAAAAAIEBAQEBQUKCwwODxAUFhkeICEnKCoqKywsLC0wMDA0XcIXvQAAAEZJREFUeNoFQAcSQDAQXG3V6NFCHCH+/0MD1iLuVET19jGbp4AZmUWz3iEIua28YKtFHwxu2G76Eo4GuW9jDr5EpKwTUekPp2QEsxJhep0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loan-feature-6.2eed7364.png","height":50,"width":51,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAnUlEQVR42lWN2wrCMBBEQ6F4oT6olSZ5EKrW3mzF79jND0s33+YkRNCFQ3Z2JowKc+J3plkuv1RuydR3LEttWJ5/OKmjCWEhZvAAfWICL3hGGZIRy9k4n+M9gKPC4L6x7OewdJZkDWMH+sQ2VpMfQmCIwkmezLtx+E1SINCGwAT2FS0rmKVGjealwH5FxahCJ46dJmnBDTQRlsawlB8hoEc+pBatXwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const LoanForm = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        action: "#",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-6",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "single-input",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "name",
                                    children: "Name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "text",
                                    id: "name",
                                    placeholder: " name?",
                                    required: true
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-6",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "single-input",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    htmlFor: "email",
                                    children: "Email"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "text",
                                    id: "email",
                                    placeholder: "email?",
                                    required: true
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-6",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "single-input",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "phone",
                                children: "Phone"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                id: "phone",
                                placeholder: "(123) 480 - 3540",
                                required: true
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoanForm);


/***/ })

};
;
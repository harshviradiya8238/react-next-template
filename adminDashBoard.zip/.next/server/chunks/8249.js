"use strict";
exports.id = 8249;
exports.ids = [8249];
exports.modules = {

/***/ 8578:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/cards/CareerCard.jsx


const CareerCard_CareerCard = ({ career  })=>{
    const { position , title , desc , link  } = career;
    return /*#__PURE__*/ _jsxs("div", {
        className: "single-item",
        children: [
            /*#__PURE__*/ _jsx("h5", {
                children: title
            }),
            /*#__PURE__*/ _jsx("p", {
                children: desc
            }),
            /*#__PURE__*/ _jsx(Link, {
                href: link,
                className: "cmn-btn",
                children: "Apply Now"
            })
        ]
    });
};
/* harmony default export */ const cards_CareerCard = ((/* unused pure expression or super */ null && (CareerCard_CareerCard)));

// EXTERNAL MODULE: ./components/about/aboutData.js + 3 modules
var aboutData = __webpack_require__(9237);
;// CONCATENATED MODULE: ./components/about/Career.jsx




const Career = ()=>{
    return /*#__PURE__*/ _jsx("section", {
        className: "current-positions",
        children: /*#__PURE__*/ _jsx("div", {
            className: "overlay pt-120 pb-120",
            children: /*#__PURE__*/ _jsxs("div", {
                className: "container wow fadeInUp",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ _jsx("div", {
                            className: "col-xl-9 col-lg-10",
                            children: /*#__PURE__*/ _jsxs("div", {
                                className: "section-header text-center",
                                children: [
                                    /*#__PURE__*/ _jsx("h3", {
                                        className: "sub-title",
                                        children: "Our Services"
                                    }),
                                    /*#__PURE__*/ _jsx("p", {
                                        children: "Grow with us and take your professional life to the next level."
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "row mb-60",
                        children: career_data.map((career, i)=>/*#__PURE__*/ _jsx("div", {
                                className: "col-lg-3 col-md-3",
                                children: /*#__PURE__*/ _jsx(CareerCard, {
                                    career: career
                                })
                            }, career.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const about_Career = ((/* unused pure expression or super */ null && (Career)));


/***/ }),

/***/ 9237:
/***/ (() => {


// UNUSED EXPORTS: career_data, core_values_data

;// CONCATENATED MODULE: ./public/images/icon/core-values-1.png
/* harmony default export */ const core_values_1 = ({"src":"/_next/static/media/core-values-1.c1e789b7.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAWElEQVR42kXMuw2AMBAE0QWROEJyBokrQFh8CnBiCqH/Fkas7AC9ZG6DE2oOzl5iRFxku/HVh0Kw8g8rry19EBuVzE51Scw8qHPNIrVnk8mVRCAiBhOR8AGF6kUhUF1q/QAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/core-values-2.png
/* harmony default export */ const core_values_2 = ({"src":"/_next/static/media/core-values-2.a5dba95c.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAWUlEQVR42j2JMQqAMBAEL2BlJwRBQcRC+7QiWIlK0ML/v2Xwcmi2mN1lRISCRjS0uFQVkYWdQ3lSik5vtlZ2rMLMJF8IhFQXvd2R7TcPnoFoB2e8ifkZsnwBqkYplbc7cAAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/core-values-3.png
/* harmony default export */ const core_values_3 = ({"src":"/_next/static/media/core-values-3.5175ee39.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAXElEQVR42lXFMQrCQAAF0R8NgoWFlQoaTEBBXCy0SCPYeRTvf4KHWwXCY5jIXLQ6EavqbB1HvY/R4KnXxcNOcXcy1ErsvYw24uJtG5Wvn4ObpUQj4qpoxSIqjel/XiJEj+1m2lcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/about/aboutData.js



const career_data = [
    {
        id: 1,
        position: "Management",
        title: "Home Loan",
        desc: "Proin sed eros ac libero auctor egestas. Duis maximus imperdiet ultricies. Donec finibus diam risus",
        link: "/register"
    },
    {
        id: 2,
        position: "Developer",
        title: "Personal Loan",
        desc: "Proin sed eros ac libero auctor egestas. Duis maximus imperdiet ultricies. Donec finibus diam risus",
        link: "/register"
    },
    {
        id: 3,
        position: "Developer",
        title: "Car Loan",
        desc: "Proin sed eros ac libero auctor egestas. Duis maximus imperdiet ultricies. Donec finibus diam risus",
        link: "/register"
    },
    {
        id: 4,
        position: "Design",
        title: "Education Loan",
        desc: "Proin sed eros ac libero auctor egestas. Duis maximus imperdiet ultricies. Donec finibus diam risus",
        link: "/register"
    }
];
const core_values_data = [
    {
        id: 1,
        icon: core_values_1,
        title: "Customer First",
        desc: "We aim to provide our customers with top-notch service that helps them grow their business and put their best foot forward."
    },
    {
        id: 2,
        icon: core_values_2,
        title: "Passion over Pedigree",
        desc: "We hire for passion, because passionate people can overcome any obstacle and acquire any knowledge necessary."
    },
    {
        id: 3,
        icon: core_values_3,
        title: "Commitment",
        desc: "Our first priority is to keep your money safe and secure. Every single aspect of our service is optimized to protect and grow your funds!"
    }
];


/***/ }),

/***/ 1181:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _carouselData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5127);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);





// Import css files

const Next = ({ onClick  })=>{
    return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "slick-arrow slick-prev pull-left",
        onClick: onClick,
        children: /*#__PURE__*/ _jsx("i", {
            children: /*#__PURE__*/ _jsx(BsChevronLeft, {})
        })
    });
};
const Prev = ({ onClick  })=>{
    return /*#__PURE__*/ _jsx("button", {
        type: "button",
        className: "slick-arrow slick-next pull-right",
        onClick: onClick,
        children: /*#__PURE__*/ _jsx("i", {
            children: /*#__PURE__*/ _jsx(BsChevronRight, {})
        })
    });
};
const JourneyCarousel = ()=>{
    const settings = {
        infinite: true,
        autoplay: false,
        focusOnSelect: false,
        speed: 1000,
        slidesToShow: 4,
        slidesToScroll: 1,
        arrows: true,
        prevArrow: /*#__PURE__*/ _jsx(Next, {}),
        nextArrow: /*#__PURE__*/ _jsx(Prev, {}),
        dots: false,
        dotsClass: "section-dots",
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true
                }
            }
        ]
    };
    return /*#__PURE__*/ _jsx(Slider, {
        ...settings,
        className: "journey-carousel",
        children: journey_carousel_data.map((itm, i)=>/*#__PURE__*/ _jsx("div", {
                className: "single",
                children: /*#__PURE__*/ _jsxs("div", {
                    className: "single-box",
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: "top-box d-flex align-items-center",
                            children: [
                                /*#__PURE__*/ _jsx("div", {
                                    className: "icon-box",
                                    children: /*#__PURE__*/ _jsx(Image, {
                                        src: itm.icon,
                                        alt: "icon"
                                    })
                                }),
                                /*#__PURE__*/ _jsx("h4", {
                                    children: itm.year
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx("div", {
                            className: "text-box",
                            children: /*#__PURE__*/ _jsx("p", {
                                children: itm.desc
                            })
                        })
                    ]
                })
            }, itm.id))
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (JourneyCarousel)));


/***/ }),

/***/ 5127:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "P": () => (/* binding */ journey_carousel_data)
});

;// CONCATENATED MODULE: ./public/images/icon/our-journey-1.png
/* harmony default export */ const our_journey_1 = ({"src":"/_next/static/media/our-journey-1.96129692.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAbElEQVR42jXNIQ6BAQAG0A9RMUHCdKNIgk0xNk2QKAoaycam0Mym2VzE7d6U37vAi1KSGOnnT8/Q3EZTRzdqDh7GFgYmLrH0dnT0cXfyjJ26m6mtu4Zz7FV8XZ28ErMYaFmralsl2sVU5OXkB9EHQQYPA/nnAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/our-journey-2.png
/* harmony default export */ const our_journey_2 = ({"src":"/_next/static/media/our-journey-2.06ecea65.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAcklEQVR42iXLvQpBARgA0K8UK6td/iIPQDJIIpIspFgoJXXvoJTRIi9gkMF7nhRnPyEToWKgZaQRf85eZsouCqHm6GbrIC9xD2+psY6+pqFJ+Lh62vxq1yj0PKSyEXL2dqEqMTVWUtd2CkUrS31rcwu9Lw2xSqAH+BDKAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/our-journey-3.png
/* harmony default export */ const our_journey_3 = ({"src":"/_next/static/media/our-journey-3.0730567d.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAa0lEQVR42l3BLQrCABgA0K+K2WIwW3YJw4IgavQPBBGWNQgGizgRmywZTKI3GJ7uYdjS3ouKXkRN18LVVmZqohVmLjI3iaOvNKwNpV5OShuj8PDzdDCw9JaHQinx0Ta2dw+5Qt9Zx9zKLpr+crJEoPnDPycAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/icon/our-journey-4.png
/* harmony default export */ const our_journey_4 = ({"src":"/_next/static/media/our-journey-4.f1dd2b45.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAnElEQVR42mNAB////xf+9++fPZDWQ5cw//TlV+Kv338zgGw7oKJiIC0Ak1T88fNP+8Xrb2z//fufvHTtDUagWBRQETcDDPz89acJqDv5799/wd++/84DKvCF6eYAqswB0rOAeBKQvRpILwLS+mAFQIYpUGAqkM4F4h4g9gfiEqAYF0yBEhDXAnEvEEsAheAAyGdEMBCCzEDMCBMDAHMVjnGEGrqfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/carousel/carouselData.js




const journey_carousel_data = [
    {
        id: 1,
        icon: our_journey_1,
        year: 2019,
        desc: "Nam blandit volutpat arcu. Nullam vitae elit arcu. Duis nec faucibus sapien. In sagittis, mauris vel laoreet elementum",
        src: "/images/apply-for-loan-bg.png",
        name: "John Test"
    },
    {
        id: 2,
        icon: our_journey_2,
        year: 2020,
        desc: "Nam blandit volutpat arcu. Nullam vitae elit arcu. Duis nec faucibus sapien. In sagittis, mauris vel laoreet elementum",
        src: "/images/apply-for-loan-bg.png",
        name: "John Test"
    },
    {
        id: 3,
        icon: our_journey_3,
        year: 2021,
        desc: "Nam blandit volutpat arcu. Nullam vitae elit arcu. Duis nec faucibus sapien. In sagittis, mauris vel laoreet elementum",
        src: "/images/apply-for-loan-bg.png",
        name: "John Test"
    },
    {
        id: 4,
        icon: our_journey_4,
        year: 2022,
        desc: "Nam blandit volutpat arcu. Nullam vitae elit arcu. Duis nec faucibus sapien. In sagittis, mauris vel laoreet elementum",
        src: "/images/apply-for-loan-bg.png",
        name: "John Test"
    },
    {
        id: 5,
        icon: our_journey_1,
        year: 2023,
        desc: "Nam blandit volutpat arcu. Nullam vitae elit arcu. Duis nec faucibus sapien. In sagittis, mauris vel laoreet elementum",
        src: "/images/apply-for-loan-bg.png",
        name: "John Test"
    }
];


/***/ })

};
;
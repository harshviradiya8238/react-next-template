"use strict";
exports.id = 3894;
exports.ids = [3894];
exports.modules = {

/***/ 3894:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ navBar_NavBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./components/navBar/navData.js
const navData = [
    {
        id: "au@81",
        itm: "Home",
        url: "/",
        dropdown: false
    },
    {
        id: "au@2_91",
        itm: "About Us",
        url: "/about",
        dropdown: false
    },
    {
        id: "au@2_66",
        itm: "Services ",
        url: "/services",
        dropdown: false
    },
    {
        id: "au@123",
        itm: "Loan Application ",
        url: "/loanapplication",
        dropdown: false
    },
    // {
    //   id: "au@201",
    //   itm: "Product",
    //   url: "#",
    //   dropdown: true,
    //   dropdown_itms: [
    //     {
    //       id: "du@01",
    //       dp_itm: "Account",
    //       url: "#",
    //       sbu_dropdown: true,
    //       sub_items: [
    //         {
    //           id: "sub@01",
    //           sub_itm: "Account",
    //           url: "/account",
    //         },
    //         {
    //           id: "sub@02",
    //           sub_itm: "Account Details",
    //           url: "/account-details",
    //         },
    //       ],
    //     },
    //     {
    //       id: "du@02",
    //       dp_itm: "Product",
    //       url: "/product",
    //     },
    //     {
    //       id: "du@03",
    //       dp_itm: "Loan",
    //       url: "#",
    //       sbu_dropdown: true,
    //       sub_items: [
    //         {
    //           id: "sub@001",
    //           sub_itm: "Business Loans",
    //           url: "/business-loan",
    //         },
    //         {
    //           id: "sub@002",
    //           sub_itm: "Educations Loans",
    //           url: "/educations-loan",
    //         },
    //         {
    //           id: "sub@003",
    //           sub_itm: "Home Loans",
    //           url: "/home-loan",
    //         },
    //         {
    //           id: "sub@004",
    //           sub_itm: "Car Loans",
    //           url: "/car-loan",
    //         },
    //         {
    //           id: "sub@005",
    //           sub_itm: "Personal Loans",
    //           url: "/personal-loan",
    //         },
    //       ],
    //     },
    //     {
    //       id: "du@04",
    //       dp_itm: "Card",
    //       url: "/card",
    //     },
    //   ],
    // },
    // {
    //   id: "au@2331",
    //   itm: "Pages",
    //   url: "#",
    //   dropdown: true,
    //   dropdown_itms: [
    //     {
    //       id: "du@01s",
    //       dp_itm: "Affiliate",
    //       url: "/affiliate",
    //     },
    //     {
    //       id: "du@02s",
    //       dp_itm: "Blog",
    //       url: "/Blog",
    //       sbu_dropdown: true,
    //       sub_items: [
    //         {
    //           id: "sub@0001",
    //           sub_itm: "Blog List",
    //           url: "/blog-list",
    //         },
    //         {
    //           id: "sub@0002",
    //           sub_itm: "Blog Grid",
    //           url: "/blog-grid",
    //         },
    //         {
    //           id: "sub@0003",
    //           sub_itm: "Blog Single",
    //           url: "/blog-single",
    //         },
    //       ],
    //     },
    //     {
    //       id: "du@03s",
    //       dp_itm: "Remittance",
    //       url: "/remittance",
    //     },
    //     {
    //       id: "du@04s",
    //       dp_itm: "Career Single",
    //       url: "/career-single",
    //     },
    //     {
    //       id: "du@05s",
    //       dp_itm: "Faqs",
    //       url: "/faqs",
    //     },
    //     {
    //       id: "du@06s",
    //       dp_itm: "login",
    //       url: "/login",
    //     },
    //     {
    //       id: "du@07s",
    //       dp_itm: "Password Set",
    //       url: "/password-set",
    //     },
    //     {
    //       id: "du@08s",
    //       dp_itm: " Varify Number",
    //       url: "/varify-number",
    //     },
    //     {
    //       id: "du@09s",
    //       dp_itm: "OTP",
    //       url: "/otp",
    //     },
    //     {
    //       id: "du@10s",
    //       dp_itm: "Terms Conditions",
    //       url: "/privacy-policy",
    //     },
    //   ],
    // },
    {
        id: "au@221",
        itm: "Contact Us",
        url: "/contact",
        dropdown: false
    }
];

// EXTERNAL MODULE: ./public/images/logo.png
var logo = __webpack_require__(8350);
;// CONCATENATED MODULE: ./components/navBar/NavBar.jsx







// import { Button } from "bootstrap";
const NavBar = ({ userLoginData  })=>{
    const [windowHeight, setWindowHeight] = (0,external_react_.useState)(0);
    // const [userLoginData, setUserLoginData] = useState("");
    const [newData, setNewData] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        // You can also set state in a useEffect block
        if (!userLoginData) {
            if (false) { var data, stroge; }
        } else {
            setNewData(userLoginData);
        }
    }, [
        userLoginData
    ]);
    const menus = (0,external_react_.useRef)();
    const hidenMenu = ()=>{
        menus.current.classList.remove("show");
    };
    const navBarTop = ()=>{
        if (window !== undefined) {
            let height = window.scrollY;
            setWindowHeight(height);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", navBarTop);
        return ()=>{
            window.removeEventListener("scroll", navBarTop);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: `header-section ${windowHeight > 50 && "header-fixed animated fadeInDown"}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "overlay",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row d-flex header-area",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                        className: "navbar navbar-expand-lg navbar-light",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "navbar-toggler collapsed",
                                type: "button",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#navbar-content",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaBars, {})
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "collapse navbar-collapse justify-content-end",
                                id: "navbar-content",
                                ref: menus,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        className: "navbar-nav mr-auto mb-2 mb-lg-0",
                                        children: navData.map(({ itm , url , id , dropdown , dropdown_itms  })=>{
                                            return !dropdown ? /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    className: "nav-link",
                                                    "aria-current": "page",
                                                    href: url,
                                                    onClick: hidenMenu,
                                                    children: itm
                                                })
                                            }, id) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: "nav-item dropdown main-navbar",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        className: "nav-link dropdown-toggle",
                                                        href: "/",
                                                        "data-bs-toggle": "dropdown",
                                                        "data-bs-auto-close": "outside",
                                                        children: itm
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        className: "dropdown-menu main-menu shadow",
                                                        children: dropdown_itms?.map(({ id , dp_itm , url , sbu_dropdown , sub_items  })=>!sbu_dropdown ? /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    className: "nav-link",
                                                                    href: url,
                                                                    onClick: hidenMenu,
                                                                    children: dp_itm
                                                                })
                                                            }, id) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                className: "dropend sub-navbar",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "/",
                                                                        className: "dropdown-item dropdown-toggle",
                                                                        "data-bs-toggle": "dropdown",
                                                                        "data-bs-auto-close": "outside",
                                                                        children: dp_itm
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                                        className: "dropdown-menu sub-menu shadow",
                                                                        children: sub_items?.map(({ id , url , sub_itm  })=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                    className: "nav-link",
                                                                                    href: url,
                                                                                    onClick: hidenMenu,
                                                                                    children: sub_itm
                                                                                })
                                                                            }, id))
                                                                    })
                                                                ]
                                                            }, id))
                                                    })
                                                ]
                                            }, id);
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "right-area header-action d-flex align-items-center m-0",
                                        children: newData ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                    className: "navbar-nav mr-auto mb-2 mb-lg-0 me-5",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "/userDashBoard",
                                                            className: "nav-link",
                                                            children: "Dashboard"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "login_Name",
                                                    children: [
                                                        newData.firstName,
                                                        " ",
                                                        newData.lastName
                                                    ]
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/login",
                                                    className: "cmn-btn me-3",
                                                    onClick: hidenMenu,
                                                    children: "Login"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/registerApplication",
                                                    className: "cmn-btn ",
                                                    onClick: hidenMenu,
                                                    children: "Sign Up"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const navBar_NavBar = (NavBar);


/***/ })

};
;
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 8350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.c5e2d9fb.png","height":32,"width":131,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAASUlEQVR4nGMUCG1r+sf47Rr3d4fXDAwMLEz/OH9/5t4u+oWt5TPzfxMWoILW+v+Mf15zfbe8wsDALMb0j/09UAH3F7bWn0AFTACa1RvC8PiA6AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 4112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_notifications__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5974);
/* harmony import */ var react_notifications__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_notifications__WEBPACK_IMPORTED_MODULE_0__);

const Notification = (type, message)=>{
    switch(type){
        case "info":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.info(message);
            break;
        case "success":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.success(message);
            break;
        case "warning":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.warning(message);
            break;
        case "error":
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.error(message || "Something Went Wrong");
            break;
        default:
            react_notifications__WEBPACK_IMPORTED_MODULE_0__.NotificationManager.info(message);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Notification);


/***/ }),

/***/ 6093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.min.css
var bootstrap_min = __webpack_require__(9090);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/footer/Footer.jsx + 2 modules
var Footer = __webpack_require__(4131);
// EXTERNAL MODULE: ./components/navBar/NavBar.jsx + 1 modules
var NavBar = __webpack_require__(3894);
// EXTERNAL MODULE: ./components/preloader/Preloader.jsx
var Preloader = __webpack_require__(3525);
// EXTERNAL MODULE: ./components/ready/Ready.jsx + 1 modules
var Ready = __webpack_require__(6385);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./components/scrollToTop/ScrollToTop.jsx




const ScrollToTop = ()=>{
    const scrollTop = (0,external_react_.useRef)();
    (0,external_react_.useEffect)(()=>{
        window.scroll({
            top: 0,
            left: 0
        });
    });
    // useEffect(() => {
    //   window.addEventListener("scroll", () => {
    //     if (window.scrollY > 200) {
    //       scrollTop.current.classList.add("active");
    //     } else {
    //       scrollTop?.current.classList.remove("active");
    //     }
    //   });
    // }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "#gotoTop",
        className: "scrollToTop",
        ref: scrollTop,
        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleDoubleUp, {})
        })
    });
};
/* harmony default export */ const scrollToTop_ScrollToTop = (ScrollToTop);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "@fortawesome/react-fontawesome"
const react_fontawesome_namespaceObject = require("@fortawesome/react-fontawesome");
;// CONCATENATED MODULE: ./components/userDashBoardComponent/Sidebar.jsx


// import "../../public/dashBoardCss/css/style.css";




function Sidebar({ toggleSidebar , isOpen  }) {
    //   const [activeItem, setActiveItem] = useState("dashboard");
    //   const handleItemClick = (item) => {
    //     setActiveItem(item);
    //   };
    const router = (0,router_.useRouter)();
    const { pathname  } = router;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            class: `sidebar sticky-top  ${isOpen ? "side_nav" : "side_nav_close"}`,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    class: "header-box ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                            class: "fs-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    class: "img-box",
                                    children: [
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/images/logoDashBoard.png",
                                            alt: ""
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    class: "text-white",
                                    children: "Loan Bazaar"
                                }),
                                " "
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-white mr-10 pe-auto",
                            onClick: toggleSidebar,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                class: "fa-solid fa-arrow-left"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            class: "btn d-md-none close-btn px-1 py-0 "
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    class: "ul-section top ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: `${pathname === "/userDashBoard" ? "active" : "normal"}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/userDashBoard",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fa-solid fa-gauge"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        class: "text",
                                        children: "Dashboard"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: ` ${pathname.includes("loanApplication") ? "active" : ""}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/userDashBoard/loanApplication",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fa-solid fa-plus"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        class: "text",
                                        children: "New Loan Request"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: ` ${pathname.includes("myloan") ? "active" : ""}`,
                            children: [
                                " ",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/userDashBoard/myloan",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            class: "fa-solid fa-note-sticky"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            class: "text",
                                            children: "My Loan"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: `${pathname.includes("cashback") ? "active" : ""}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/userDashBoard/cashback",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fa-solid fa-sack-dollar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        class: "text",
                                        children: "Cashback"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: ` ${pathname.includes("earn") ? "active" : ""}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/userDashBoard/earn",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fa-solid fa-gift"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        class: "text",
                                        children: "Refer & Earn"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: ` ${pathname.includes("profile") ? "active" : ""}`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/userDashBoard/profile",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fa-solid fa-user"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        class: "text",
                                        children: "Profile"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const userDashBoardComponent_Sidebar = (Sidebar);

;// CONCATENATED MODULE: external "react-bootstrap/Button"
const Button_namespaceObject = require("react-bootstrap/Button");
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_namespaceObject);
;// CONCATENATED MODULE: external "react-bootstrap/Modal"
const Modal_namespaceObject = require("react-bootstrap/Modal");
var Modal_default = /*#__PURE__*/__webpack_require__.n(Modal_namespaceObject);
// EXTERNAL MODULE: ./components/utils/Notification.js
var Notification = __webpack_require__(4112);
;// CONCATENATED MODULE: ./components/logoutModal/LogoutModal.js





function LogoutModal({ show , close  }) {
    const router = (0,router_.useRouter)();
    const handleLogout = async ()=>{
        await localStorage.clear();
        await router.push("/login");
        (0,Notification/* default */.Z)("success", "Logout successFully");
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "modal show d-block",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Modal_default()), {
            show: show,
            onHide: close,
            style: {
                zIndex: "9999"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Modal_default()).Header, {
                    closeButton: true
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Modal_default()).Body, {
                    children: "Are you sure, you want to logout?"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Modal_default()).Footer, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            variant: "secondary",
                            onClick: close,
                            class: "Cancel-btn",
                            children: "Cancel"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            variant: "primary",
                            onClick: handleLogout,
                            class: "Logout-btn",
                            children: "Yes"
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const logoutModal_LogoutModal = (LogoutModal);

;// CONCATENATED MODULE: ./components/userDashBoardComponent/dashboardNavbar/navbar.js




function Navbar({ toggleSidebar  }) {
    const router = (0,router_.useRouter)();
    const [showLogout, setShowLogout] = (0,external_react_.useState)(false);
    const [userData, setUserData] = (0,external_react_.useState)("");
    (0,external_react_.useEffect)(()=>{
        // Initial data setting
        setUserData( false ? 0 : "");
        const handleStorageChange = (e)=>{
            if (e.key === "user") {
                setUserData(JSON.parse(e.newValue));
            }
        };
        window.addEventListener("storage", handleStorageChange);
        return ()=>{
            window.removeEventListener("storage", handleStorageChange);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            class: "navbarDashBoard navbar-expand-md sticky-top",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                class: "container mw-100",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        class: "d-flex justify-content-between align-items-center ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                class: "m-10 text-white",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "fa-solid fa-bars-staggered",
                                    onClick: toggleSidebar
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                class: "profile-section ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    class: "navbar-nav ms-auto ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            class: "dropdown",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    class: "dropdown-toggle user-dropdown",
                                                    type: "button",
                                                    "data-bs-toggle": "dropdown",
                                                    "aria-expanded": "false",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            class: "user-icon",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                    src: "/images/user.png",
                                                                    alt: ""
                                                                }),
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "me-2",
                                                            children: userData?.firstName
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: userData?.lastName
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    class: "dropdown-menu ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "p-10",
                                                            children: userData?.email
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            onClick: ()=>{
                                                                setShowLogout(true);
                                                            // localStorage.clear();
                                                            // router.push("/login");
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                class: "dropdown-item",
                                                                href: "#",
                                                                children: "Logout"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        class: "modal model-card fade",
                        id: "staticBackdrop",
                        "data-bs-backdrop": "static",
                        "data-bs-keyboard": "false",
                        tabindex: "-1",
                        "aria-labelledby": "staticBackdropLabel",
                        "aria-hidden": "true",
                        children: showLogout && /*#__PURE__*/ jsx_runtime_.jsx(logoutModal_LogoutModal, {
                            show: showLogout,
                            close: ()=>setShowLogout(false)
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const navbar = (Navbar);

// EXTERNAL MODULE: external "react-notifications"
var external_react_notifications_ = __webpack_require__(5974);
// EXTERNAL MODULE: ./node_modules/react-notifications/lib/notifications.css
var notifications = __webpack_require__(9013);
;// CONCATENATED MODULE: ./helper/useAutoLogout.js
// hooks/useAutoLogout.js


// Function to handle the logout process
const handleLogout = ()=>{
    // Your logout logic here
    // For example, remove a JWT token from localStorage
    // Redirect user to the login page
    window.location.reload();
    window.location.href = "/";
    localStorage.clear();
//   Router.push('/login');
};
const useAutoLogout = (timeout)=>{
    (0,external_react_.useEffect)(()=>{
        let logoutTimer;
        // Function to reset the timer
        const resetTimer = ()=>{
            clearTimeout(logoutTimer);
            logoutTimer = setTimeout(handleLogout, timeout);
        };
        // Set and reset the timer whenever an action is taken
        resetTimer();
        window.addEventListener("mousemove", resetTimer);
        window.addEventListener("mousedown", resetTimer);
        window.addEventListener("click", resetTimer);
        window.addEventListener("scroll", resetTimer);
        window.addEventListener("keypress", resetTimer);
        return ()=>{
            // Cleanup: Remove all event listeners and clear the timer
            clearTimeout(logoutTimer);
            window.removeEventListener("mousemove", resetTimer);
            window.removeEventListener("mousedown", resetTimer);
            window.removeEventListener("click", resetTimer);
            window.removeEventListener("scroll", resetTimer);
            window.removeEventListener("keypress", resetTimer);
        };
    }, [
        timeout
    ]);
};
/* harmony default export */ const helper_useAutoLogout = (useAutoLogout);

;// CONCATENATED MODULE: ./helper/useAuth.js
// hooks/useAuth.js


function useAuth() {
    const router = useRouter();
    const isAuthenticated =  false ? 0 : false;
    return isAuthenticated;
}
/* harmony default export */ const helper_useAuth = ((/* unused pure expression or super */ null && (useAuth)));

;// CONCATENATED MODULE: ./components/layout.js















const Layout = ({ children  })=>{
    const router = (0,router_.useRouter)();
    const { pathname  } = router;
    // const isAuthenticated = useAuth();
    // useAutoLogout(24 * 60 * 1000);
    // useEffect(() => {
    //   if (pathname.includes("userDashBoard") && !isAuthenticated) {
    //     router.push("/login");
    //   }
    // }, [isAuthenticated, pathname]);
    const [isOpen, setIsOpen] = (0,external_react_.useState)(true);
    const toggleSidebar = ()=>{
        setIsOpen(!isOpen);
    };
    // useEffect(() => {
    //   const handleBeforePopState = (event) => {
    //     if (event.state && event.state.route === "/userDashboard") {
    //       router.replace("/userDashboard", undefined, { shallow: true });
    //       // event.preventDefault();
    //     }
    //   };
    //   window.addEventListener("beforepopstate", handleBeforePopState);
    //   return () => {
    //     window.removeEventListener("beforepopstate", handleBeforePopState);
    //   };
    // }, [router]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            pathname.includes("userDashBoard") ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(navbar, {
                        toggleSidebar: toggleSidebar
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(userDashBoardComponent_Sidebar, {
                        isOpen: isOpen,
                        toggleSidebar: toggleSidebar
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(NavBar/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: pathname.includes("userDashBoard") && isOpen === true ? "wrapper" : "wrapper_close",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_notifications_.NotificationContainer, {
                        className: "my-custom-notifications"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Preloader/* default */.Z, {}),
                    children
                ]
            }),
            pathname.includes("userDashBoard") ? "" : /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(scrollToTop_ScrollToTop, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Preloader/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const layout = (Layout);

// EXTERNAL MODULE: ./styles/globals.scss
var globals = __webpack_require__(3716);
// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-free/css/all.min.css
var all_min = __webpack_require__(4595);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: external "redux-devtools-extension"
const external_redux_devtools_extension_namespaceObject = require("redux-devtools-extension");
;// CONCATENATED MODULE: ./store/reducers/counter.js
// reducers.js
const initialState = {
    count: 0,
    isLoading: false,
    error: null
};
const counterReducer = (state = initialState, action)=>{
    switch(action.type){
        case "FETCH_POSTS_REQUEST":
            return {
                ...state,
                isLoading: true
            };
        case "FETCH_POSTS_SUCCESS":
            return {
                ...state,
                isLoading: false,
                posts: action.payload
            };
        case "FETCH_POSTS_FAILURE":
            return {
                ...state,
                isLoading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
/* harmony default export */ const counter = (counterReducer);

;// CONCATENATED MODULE: ./store/constant.js
const SUCCESS_ADD_USER = "SUCCESS_ADD_USER";
const ERROR_ADD_USER = "ERROR_ADD_USER";
const SUCCESS_USER_LOGIN = "SUCCESS_USER_LOGIN";
const ERROR_USER_LOGIN = "ERROR_USER_LOGIN";
const SUCCESS_USER_DETAILS = "SUCCESS_USER_DETAILS";
const ERROR_USER_DETAILS = "ERROR_USER_DETAILS";
const SUCCESS_LOAN_TYPE = "SUCCESS_LOAN_TYPE";
const ERROR_LOAN_TYPE = "ERROR_LOAN_TYPE";

;// CONCATENATED MODULE: ./store/reducers/userAuthReducer.js

const userAuthReducer_initialState = {
    userDetails: {},
    allUsers: [],
    loading: false,
    error: ""
};
// ==============================|| CUSTOMIZATION REDUCER ||============================== //
const userReducer = (state = userAuthReducer_initialState, action)=>{
    switch(action.type){
        case SUCCESS_ADD_USER:
            const { data  } = action.payload;
            return {
                ...state,
                allUsers: [
                    ...state.allUsers,
                    data
                ],
                loading: false
            };
        case ERROR_ADD_USER:
            return {
                ...state,
                loading: false,
                error: action.payload.error
            };
        // case USER_LOGIN:
        //     return { ...state, loading: true };
        // case SUCCESS_USER_LOGIN:
        //     return { ...state, userDetails: action.payload, loading: false };
        // case ERROR_USER_LOGIN:
        //     return { ...state, loading: false };
        // case USER_DETAILS:
        //     return { ...state };
        // case SUCCESS_USER_DETAILS:
        //     return { ...state, userDetails: action.payload };
        // case ERROR_USER_DETAILS:
        //     return { ...state };
        // case GET_CANDIDATES:
        //     return { ...state, loading: true };
        // case GET_CANDIDATES_SUCCESS:
        //     return { ...state, loading: false, candidates: action.payload };
        // case GET_CANDIDATES_ERROR:
        //     return { ...state, loading: false };
        // case GET_CANDIDATES_BY_ID:
        //     return { ...state, loading: true };
        // case GET_CANDIDATES_BY_ID_SUCCESS:
        //     return { ...state, loading: false, selectedCandidate: action.payload };
        // case GET_CANDIDATES_BY_ID_ERROR:
        //     return { ...state, loading: false };
        default:
            return {
                ...state
            };
    }
};
/* harmony default export */ const userAuthReducer = (userReducer);

;// CONCATENATED MODULE: ./store/reducers/loanReducer.js

const loanReducer_initialState = {
    loanType: [],
    loading: false,
    error: ""
};
// ==============================|| CUSTOMIZATION REDUCER ||============================== //
const loanReducer = (state = loanReducer_initialState, action)=>{
    switch(action.type){
        case SUCCESS_LOAN_TYPE:
            return {
                ...state,
                loading: false,
                loanType: action.payload
            };
        case ERROR_LOAN_TYPE:
            return {
                ...state,
                loading: false
            };
        // case USER_LOGIN:
        //     return { ...state, loading: true };
        // case SUCCESS_USER_LOGIN:
        //     return { ...state, userDetails: action.payload, loading: false };
        // case ERROR_USER_LOGIN:
        //     return { ...state, loading: false };
        // case USER_DETAILS:
        //     return { ...state };
        // case SUCCESS_USER_DETAILS:
        //     return { ...state, userDetails: action.payload };
        // case ERROR_USER_DETAILS:
        //     return { ...state };
        // case GET_CANDIDATES:
        //     return { ...state, loading: true };
        // case GET_CANDIDATES_BY_ID:
        //     return { ...state, loading: true };
        // case GET_CANDIDATES_BY_ID_SUCCESS:
        //     return { ...state, loading: false, selectedCandidate: action.payload };
        // case GET_CANDIDATES_BY_ID_ERROR:
        //     return { ...state, loading: false };
        default:
            return {
                ...state
            };
    }
};
/* harmony default export */ const reducers_loanReducer = (loanReducer);

;// CONCATENATED MODULE: ./store/reducers/index.js




const reducer = (0,external_redux_namespaceObject.combineReducers)({
    count: counter,
    user: userAuthReducer,
    loan: reducers_loanReducer
});
/* harmony default export */ const reducers = (reducer);

;// CONCATENATED MODULE: ./store/index.js





const makeStore = ()=>{
    const store = (0,external_redux_namespaceObject.createStore)(reducers, (0,external_redux_devtools_extension_namespaceObject.composeWithDevTools)((0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default()))));
    return store;
};
const wrapper = (0,external_next_redux_wrapper_namespaceObject.createWrapper)(makeStore);

;// CONCATENATED MODULE: ./pages/_app.js










function App({ Component , pageProps  }) {
    helper_useAutoLogout(24 * 60 * 1000);
    (0,external_react_.useEffect)(()=>{
        __webpack_require__(399);
    }, []);
    if (Component.getLayout) {
        return Component.getLayout(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: "Loan App"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "description",
                            content: "Generated by create next app"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("link", {
                            rel: "icon",
                            href: "favicon.ico"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_react_notifications_.NotificationContainer, {
                    className: "my-custom-notifications"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            ]
        }));
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Loan App"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_notifications_.NotificationContainer, {
                        className: "my-custom-notifications"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const _app = (wrapper.withRedux(App));


/***/ }),

/***/ 4595:
/***/ (() => {



/***/ }),

/***/ 9013:
/***/ (() => {



/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 399:
/***/ ((module) => {

"use strict";
module.exports = require("bootstrap/dist/js/bootstrap.bundle.min.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 5974:
/***/ ((module) => {

"use strict";
module.exports = require("react-notifications");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,676,1664,3121,5675,3525,3894,4131,6351], () => (__webpack_exec__(6093)));
module.exports = __webpack_exports__;

})();
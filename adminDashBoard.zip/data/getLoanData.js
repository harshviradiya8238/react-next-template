import loan_feature_1 from "/public/images/icon/loan-feature-1.png";
import loan_feature_2 from "/public/images/icon/loan-feature-2.png";
import loan_feature_3 from "/public/images/icon/loan-feature-3.png";
import loan_feature_4 from "/public/images/icon/loan-feature-4.png";
import loan_feature_5 from "/public/images/icon/loan-feature-5.png";
import loan_feature_6 from "/public/images/icon/loan-feature-6.png";

const get_loan_data = [
  {
    id: 1,
    icon: loan_feature_1,
    title: "Simple Application Process",
    desc: "Lorem ipsum dolor sit amet, consectetur adiet libero.",
  },
  {
    id: 2,
    icon: loan_feature_2,
    title: "No credit check",
    desc: "Lorem ipsum dolor sit amet, consectetur adiet libero.",
  },
  {
    id: 3,
    icon: loan_feature_3,
    title: "No employment requiered",
    desc: "Lorem ipsum dolor sit amet, consectetur adiet libero.",
  },
  {
    id: 4,
    icon: loan_feature_4,
    title: "Secure loan",
    desc: "Lorem ipsum dolor sit amet, consectetur adiet libero.",
  },
  {
    id: 5,
    icon: loan_feature_5,
    title: "Fast approval",
    desc: "Lorem ipsum dolor sit amet, consectetur adiet libero.",
  },
  {
    id: 6,
    icon: loan_feature_6,
    title: "Cash within minutes",
    desc: "Lorem ipsum dolor sit amet, consectetur adiet libero.",
  },
];

export default get_loan_data;
